FHMOD.factory('Services',   function ($window, $location, $http,CONFIG) {
	
	var Url = CONFIG.web_service_url+"api/auth/service";
	
	var Obj = {};
	 
	Obj.List = function(){

		return $http.get(Url);
	}

	Obj.Save = function (data){

		return $http.post(Url,data);
	}

	Obj.SaveServiceUnit = function(data){

		return $http.post(CONFIG.web_service_url+"api/auth/services_units",data);

	}

	Obj.getServicePrice = function(){

		return $http.get(CONFIG.web_service_url+"api/auth/services_units_prices");

	}

	Obj.SaveServicePrice = function(data){

		return $http.post(CONFIG.web_service_url+"api/auth/services_units_prices",data);

	}

	Obj.UpdateServicePrice = function(data,id){

		return $http.put(CONFIG.web_service_url+"api/auth/services_units_prices/"+id,data);

	}

	Obj.deleteServicePrice = function(id){

		return $http.delete(CONFIG.web_service_url+"api/auth/services_units_prices/"+id);

	}

	Obj.UpdateServiceUnit = function(data,id){

		return $http.put(CONFIG.web_service_url+"api/auth/services_units/"+id,data);

	}

	Obj.ServiceUnitList = function(){

		return $http.get(CONFIG.web_service_url+"api/auth/services_units");

	}

	Obj.LoadUnits = function(){

		return $http.get()

	}
 
	Obj.getOne = function(id){

		return $http.get(Url+"/"+id);
	}
	
	Obj.delete = function(id){

		return $http.delete(Url+"/delete/"+id);

	}
	
	Obj.update = function(data,id){

		

		return $http.put(Url+"/"+id,data);

	}
 
	Obj.block = function(id){ 

		return $http.put(Url+"/"+id);

	}
	
	Obj.unblock = function(id){

		return $http.put(Url+"/"+id);

	}

	Obj.List_grouped  = function(){

		return $http.get(Url+"/single/line/list");

	}
	
	return Obj;
	
});