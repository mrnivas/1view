FHMOD.factory('Employee',   function ($window, $location, $http, CONFIG, jwtHelper) {

	var Url =  CONFIG.web_service_url+"api/auth/employee";
 
	var Obj = {};

	Obj.List = function(){

		return $http.get(Url);
	}

	Obj.Save = function (data){

		return $http.post(Url,data);
	}
 
	Obj.getOne = function(id){

		return $http.get(Url+"/"+id);
	}
	
	Obj.delete = function(id){

		return $http.delete(Url+"/"+id);

	}
	
	Obj.update = function(data,id){

		return $http.put(Url+"/"+id,data);

	}

	return Obj;


});