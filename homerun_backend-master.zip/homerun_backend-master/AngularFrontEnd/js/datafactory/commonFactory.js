FHMOD.factory('Common',   function ($window, $location, $http, CONFIG, jwtHelper) {

	var Obj = {};
 
	Obj.getStates = function(){

		return $http.get(CONFIG.web_service_url+"common/statelist");

	};

	Obj.getCompanies = function(){

		return $http.get(CONFIG.web_service_url+"api/auth/companies/list/company/");

	}
 

	Obj.CompanyList = function(data){

		  

	}

	Obj.UserInfo  = {

			saltPref:"1f2dfg45e54d_36d5fgdfd3366dfg363d",

			saltSuff:"fgggd53fg_dfgdfg_fg3d1fsgdg153sdg1",

			Decode:function(str){ 

						txt = jwtHelper.urlBase64Decode( str );
						
						RemovePref = txt.substring( this.saltPref.length);
						
						suffSaltlength = this.saltPref.length;
						
						strLength = RemovePref.length
						
						CorrectText_N =  (strLength - suffSaltlength ) - 1;
						
						decodedText = RemovePref.substring(0,CorrectText_N);
						
						return decodedText;
						 
			},
			labels : { 
						'userid': {'org':'userid','enc':'_79sdfosdfsdfmas'},
						'username': {'org':'username','enc':'_9007sdfsfsdfhsdf'},
						'user_role': {'org':'user_role','enc':'_2sdf21sdsfs'},
						'company_id': {'org':'company_id','enc':'_5liwnlnlsdf'},
						'hub_id': {'org':'hub_id','enc':'_5sbdf9nhkksdbx'}
 
			},

			getToken : function(){

				var payload = {};

				if($window.sessionStorage.token){

					payload =  jwtHelper.decodeToken($window.sessionStorage.token);

				}
				else{
					
					payload.data = {};
				
				}

				return payload.data;

			},

			getValue : function(col){

				var Token = this.getToken();

				if(Token[this.labels[col]['enc']]){

					return this.Decode(Token[this.labels[col]['enc']]);

				}
				else{

					return "";

				}

			},

			getUserId : function(){ return this.getValue('userid');},

			getCompanyId:function(){ return this.getValue('company_id'); },

			getUsername:function(){ return this.getValue('username'); },

			getUserRole:function(){ return this.getValue('user_role'); },

			getHubId:function(){ return this.getValue('hub_id'); }

	}

	return Obj;

});