FHMOD.factory('Company',   function ($window, $location, $http,CONFIG) {
	
	var Url = CONFIG.web_service_url+"api/auth/companies";
	
	var Obj = {};
	 
	Obj.List = function(){

		return $http.get(Url);
	}

	Obj.Save = function (data){

		return $http.post(Url,data);
	}
 
	Obj.getOne = function(id){

		return $http.get(Url+"/"+id);
	}
	
	Obj.delete = function(id){

		return $http.delete(Url+"/"+id);

	}
	
	Obj.update = function(data,id){

		return $http.put(Url+"/"+id,data);

	}

	Obj.SaveHub = function (data){

		return $http.post(Url+"/hubs",data);
	}

	Obj.updateHub = function(data,id){

		return $http.put(Url+"/hubs/"+id,data);

	}
	
	Obj.block = function(id){ 

		return $http.put(Url+"/"+id);

	}
	
	Obj.unblock = function(id){

		return $http.put(Url+"/"+id);

	}
	
	return Obj;
	
});