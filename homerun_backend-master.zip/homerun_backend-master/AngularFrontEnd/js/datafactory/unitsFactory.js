FHMOD.factory('Units',   function ($window, $location, $http,CONFIG) {
	
	var Url = CONFIG.web_service_url+"api/auth/services/units";
	
	var Obj = {};
	 
	Obj.List = function(){

		return $http.get(Url);
	}

	Obj.Save = function (data){

		return $http.post(Url,data);
	}
 
	Obj.getOne = function(id){

		return $http.get(Url+"/"+id);
	}
	
	Obj.delete = function(id){

		return $http.delete(Url+"/delete/"+id);

	}
	
	Obj.update = function(data,id){

		

		return $http.put(Url+"/"+id,data);

	}
 
	Obj.block = function(id){ 

		return $http.put(Url+"/"+id);

	}
	
	Obj.unblock = function(id){

		return $http.put(Url+"/"+id);

	}
	
	return Obj;
	
});