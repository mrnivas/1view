// Modal Controllers
FHMOD.controller("ManageCompaniesModal",function($scope,$uibModalInstance,items,Common,Company){

	$scope.msg = items[0];

	$scope.ok = function(){

		$uibModalInstance.close("ok");

	}

	$scope.close = function(){

		$uibModalInstance.dismiss('cancel');

	}

	switch(items.option){

		case 'crud.new':
		case 'crud.edit':



		    $scope.title = items.title;
		 	$scope.Companies = [];
	        $scope.Hubs = [];
			$scope.states = [];
			$scope.ErrorDisplay = "none"; 
			$scope.LoadingDisplay = "none";
			$scope.LoadingMsg = ""; 
			$scope.model ={};
			

        	var Error = {};

	        Error.set = function(data){   

				$scope.ErrorDisplay = "block";
				$scope.Error = data ; 

			}

			Error.off = function(){

					$scope.ErrorDisplay = "none";
					$scope.Error = "" ; 

			}

			var Loading = {};
			
			$scope.OpenedId = 0;

			$scope.loadFields = function(){


	        	filds =   {
	        				"company_hub_name":_($scope.model.frmCompanyName),
							"address":_($scope.model.frmCompanyAddress),
							"contact_person_name":_($scope.model.frmCompanyContactPersonName),
							"city":_($scope.model.frmCompanyCity),
							"state":$scope.model.frmCompanyState,
							"pincode":_($scope.model.frmCompanyPinCode),
							"phone":_($scope.model.frmCompanyPhoneNo),
							"email":_($scope.model.frmHubEmail),
							"contact_person_phone":_($scope.model.frmCompanyContactPersonPhone)
				};

				return filds;
	        }

			var ClearForm = function(){

				$scope.model.frmCompanyName = "";
				$scope.model.frmCompanyAddress = "";
				$scope.model.frmCompanyContactPersonName = "";
				$scope.model.frmCompanyCity = "";
				$scope.model.frmCompanyState = "" ;
				$scope.model.frmCompanyPinCode = "" ;
				$scope.model.frmCompanyPhoneNo = "" ;
				$scope.model.frmHubEmail = "" ;
				$scope.model.frmCompanyContactPersonPhone = "" ; 

				if(items.data){
 
					_data = items.data;
 

					$scope.OpenedId = _data.id;
					$scope.model.frmCompanyName = _data.company_hub_name;
        			$scope.model.frmCompanyAddress = _data.address;
        			$scope.model.frmCompanyContactPersonName = _data.contact_person_name;
        			$scope.model.frmCompanyCity = _data.city;
        			
        			$scope.model.frmCompanyPinCode = _data.pincode;
        			$scope.model.frmCompanyPhoneNo = _data.phone;
        			$scope.model.frmHubEmail = _data.email;
        			$scope.model.frmCompanyContactPersonPhone = _data.contact_person_phone; 


				}

				$scope.formStatus = "block";
	        	
	        	Error.off();
	        	 

			}

			ClearForm();

			Common.getStates().success(function(res){

				Res = new Response(res);

	        	if(Res.isOk()){

	        		$scope.states = res.data;


	        		if(items.data)
	        		$scope.model.frmCompanyState = items.data.state;

	        		 
	        	}

	        });


			Loading.set = function(data){   

					$scope.LoadingDisplay = "block";
					$scope.LoadingMsg = data ; 

			}

			Loading.off = function(){

					$scope.LoadingDisplay = "none";
					$scope.LoadingMsg = "" ; 

			}

			  
			$scope.save = function(){

						filds = $scope.loadFields();

						Loading.set("Saving..");

			        	var saveCallback = function(_data){

							Error.off();

			        		Loading.off();
			        		
			        		console.log(_data);

			        		Res = new Response(_data);

							if(Res.isOk()){
 
								 $uibModalInstance.close('saved');
								
							}
							else{

								Error.set(Res.Msg());

							}

			        	}
			 
			        	if($scope.OpenedId != 0){
 

								filds.address_id =  items.data.address_id;
 

								Company.update(filds,$scope.OpenedId).success(saveCallback).error(function(er){ });

			        	}
			        	else{

								Company.Save(filds).success(saveCallback).error(function(er){ });
			        	}


					}  
	        

		break;

		case 'crud.delete':

		break;

	}

});

FHMOD.controller("ManageCompanies",function($scope,Company,Common,$location,$uibModal){
		 

		$scope.msg = ""; 
        
		$scope.crud = {};
 
        $scope.crud.new = function(){

				         	
        	    var ModalWindow_New = $uibModal.open({

					templateUrl : 'form.html',
					controller: 'ManageCompaniesModal',
					resolve: {
						items:function(){
							return {
								option:'crud.new',
								title:'Create New Company'
							}
						}
					}

				});

				ModalWindow_Edit.result.then(function(opt){

						if(opt == "saved"){ $scope.LoadCompanies();}

				},function(){});


        }

	 
		
		$scope.crud.delete = function(companyId,$event){

			var dt = jsonFinder($scope.Companies).findby("id").val(companyId);

			$scope.msg =["Are you sure want to delete '"+dt.data.data.company_hub_name+"' ? "];

		    var modalInstance = $uibModal.open({
						      
		      animation: true,
		      templateUrl: 'alert.html',
		      controller:'ManageCompaniesModal',
		      resolve: {

		      	 items:function(){

		      	 	return $scope.msg;

		      	 }

		      }

		    });

		    modalInstance.result.then(function(opt){

		    	DeleteHub(companyId);

		    },function(){});
 
			 
        	StopEventBubling($event);

        }

       

        $scope.openCompanyDetails = function(id){

        	var editRow = new jsonFinder($scope.Companies).findby("id").val(id) ;

        	if(editRow.result){

				var ModalWindow_Edit = $uibModal.open({

						templateUrl : 'form.html',
						controller: 'ManageCompaniesModal',
						resolve: {
							items:function(){
								return {
									option:'crud.new',
									title:'Modify Company Details',
									data:editRow.data.data
								}
							}
						}

				});     
				
				ModalWindow_Edit.result.then(function(opt){

					 if(opt == "saved"){ $scope.LoadCompanies();}

				},function(){});

			}   	

        }
 
        $scope.getStatus = function(status){

        	return Status(status);

        }

        $scope.setStatus = function(state,$event){

        	StopEventBubling($event);



        }
        $scope.OpenHub = function(companyId,$event){

			$location.path('index/hubs/'+companyId);
        	StopEventBubling($event);

        }

		var DeleteHub = function(companyId){

			var dt = jsonFinder($scope.Companies).findby("id").val(companyId);
 
			if(dt.result){

				Company.delete(companyId).success(function(_data){

  					if(_data.status == "done"){

	  					var i = dt.data.index;
	 
						$scope.Companies.splice(i,1);

  					}
					 
				});
 
			}

        }

        $scope.LoadCompanies = function(){

			Company.List().success(function(_data){

	        	if(_data.status == "done"){

	        		$scope.Companies = _data.data;
	        		
	        	}

	        }).error(function(er){


	        });

        }

        $scope.CreateHubs = function(companyId){

        	var dt = $scope.Companies;

        	$scope.Hubs = [];

        	if(dt.length > 0){

	        	for(var i in dt){

	        		if(dt[i].parent_id == companyId){

	        			$scope.Hubs[$scope.Hubs.length] = dt[i];

	        		}

	        	}

        	}


        }


		$scope.GetHubsCont = function(companyId){ 

			$scope.CreateHubs(companyId);

			return $scope.Hubs.length;

		}

		$scope.LoadCompanies();
 

});
