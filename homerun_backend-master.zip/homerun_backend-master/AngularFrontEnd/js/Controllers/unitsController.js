// Modal Controllers
 

FHMOD.controller("ManageUnitsModal",function($scope,$uibModalInstance,items,Common,Units){

	$scope.msg = items[0];

	$scope.ok = function(){

		$uibModalInstance.close("ok");

	}

	$scope.close = function(){

		$uibModalInstance.dismiss('cancel');

	}

	switch(items.option){

		case 'crud.new':
		case 'crud.edit':

		    $scope.title = items.title;
		 	$scope.units = [];  
			$scope.ErrorDisplay = "none"; 
			$scope.LoadingDisplay = "none";
			$scope.LoadingMsg = ""; 
			$scope.model ={};  

  
        	var Error = {};

	        Error.set = function(data){   

				$scope.ErrorDisplay = "block";
				$scope.Error = data ; 

			}

			Error.off = function(){

					$scope.ErrorDisplay = "none";
					$scope.Error = "" ; 

			}

			var Loading = {};
			
			$scope.OpenedId = 0;

			$scope.loadFields = function(){


	        	filds =   {

	        				"unit_name":_($scope.model.frmUnitName),
							"incrementable":_($scope.model.frmUnitIncrementable),
							"status":_($scope.model.frmUnitStatus),
							 
				};

				return filds;

	        }

			var ClearForm = function(){
 
				$scope.model.frmUnitName = ""; 
				$scope.model.frmUnitStatus = ""; 
 
 				if(items.data){
 
					_data = items.data;
					 
					$scope.OpenedId = _data.id;  
					$scope.model.frmUnitName = _data.unit_name; 
					$scope.model.frmUnitStatus = String(_data.status); 


				}

				$scope.formStatus = "block";
	        	
	        	Error.off();
	        	 

			}

			ClearForm();

 
			Loading.set = function(data){   

					$scope.LoadingDisplay = "block";
					$scope.LoadingMsg = data ; 

			}

			Loading.off = function(){

					$scope.LoadingDisplay = "none";
					$scope.LoadingMsg = "" ; 

			}

			  
			$scope.save = function(){

						filds = $scope.loadFields();

						Loading.set("Saving..");

			        	var saveCallback = function(_data){

							Error.off();

			        		Loading.off();
			        		
			        		console.log(_data);

			        		Res = new Response(_data);

							if(Res.isOk()){
 
								 $uibModalInstance.close('saved');
								
							}
							else{

								Error.set(Res.Msg());

							}

			        	}
			 
			        	if($scope.OpenedId != 0){

								Units.update(filds,$scope.OpenedId).success(saveCallback).error(function(er){ });

			        	}
			        	else{

								Units.Save(filds).success(saveCallback).error(function(er){ });
			        	}


					}  


					//$scope.LoadServices();
	        

		break;

		case 'crud.delete':

		break;

	}

});

FHMOD.controller("ManageUnits",function($scope,Units,Common,$location,$uibModal){
		  

		$scope.msg = ""; 
        
		$scope.crud = {};

		$scope.model = {};

		$scope.units = [];
 
 
        $scope.crud.new = function(parent_id){

				         	
        	    var ModalWindow_New = $uibModal.open({

					templateUrl : 'form.html',
					controller: 'ManageUnitsModal',
					resolve: {
						items:function(){
							return {
								option:'crud.new',
								title:'Create New Unit' 
							}
						}
					}

				});


				ModalWindow_New.result.then(function(opt){

						if(opt == "saved"){ $scope.Load();}

				},function(){});


        }

	 
		
		$scope.crud.delete = function(Id,$event){

			var dt = jsonFinder($scope.units).findby("id").val(Id);

			$scope.msg =["Are you sure want to delete '"+dt.data.data.unit_name+"' ? "];

		    var modalInstance = $uibModal.open({
						      
		      animation: true,
		      templateUrl: 'alert.html',
		      controller:'ManageUnitsModal',
		      resolve: {

		      	 items:function(){

		      	 	return $scope.msg;

		      	 }

		      }

		    });

		    modalInstance.result.then(function(opt){

		    	Delete(Id);

		    },function(){});
 
			 
        	StopEventBubling($event);

        }
 
        $scope.open = function(id){   
 
        	var editRow = new jsonFinder($scope.units).findby("id").val(id) ;

        	if(editRow.result){

				var ModalWindow_Edit = $uibModal.open({

						templateUrl : 'form.html',
						controller: 'ManageUnitsModal',
						resolve: {
							items:function(){
								return {
									option:'crud.new',
									title:'Modify Unit Details',
									data:editRow.data.data 
								}
							}
						}

				});     
				
				ModalWindow_Edit.result.then(function(opt){

					 if(opt == "saved"){ $scope.Load();}

				},function(){});

			}   	 

        }
 
        $scope.getStatus = function(status){

        	return Status(status);

        }

        $scope.setStatus = function(state,$event){

        	StopEventBubling($event);



        }
         

		var Delete = function(Id){

			var dt = jsonFinder($scope.units).findby("id").val(Id);
 
			if(dt.result){

				Units.delete(Id).success(function(_data){

  					if(_data.status == "done"){

	  					var i = dt.data.index;
	 
						$scope.units.splice(i,1);


  					}
					 
				});
 
			}

        }

			 

        $scope.Load = function(){

			Units.List().success(function(_data){

	        	if(_data.status == "done"){

	        		$scope.units = _data.data;
 
	        	}

	        }).error(function(er){


	        });

        }

 

		$scope.Load();
 

});