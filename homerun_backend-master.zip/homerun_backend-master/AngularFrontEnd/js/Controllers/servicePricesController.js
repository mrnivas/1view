// Modal Controllers

var allServices = [];

FHMOD.controller("ManageServicesPricesModal",function($scope,$uibModal,$uibModalInstance,items,Common,Services,Units){

	$scope.ServicePrices = [];

	$scope.msg = items[0];

	$scope.ok = function(){

		$uibModalInstance.close("ok");

	}

	$scope.close = function(){

		$uibModalInstance.dismiss('cancel');

	}

	$scope.Units = [];

	var LoadUnits = function(){

		Units.List().success(function(_data){

			if(_data.status == "done"){

				$scope.Units = _data.data;

			}

		})

	}


	var Delete = function(Id){
 
			var dt  = jsonFinder($scope.priceList).findby("id").val(Id);

			if(dt.result){

				Services.deleteServicePrice(Id).success(function(_data){

  					if(_data.status == "done"){

	  					var i = dt.data.index;
 
						$scope.priceList.splice(i,1);

  					}
					 
				});
 
			}

    };


	switch(items.option){

		case 'crud.new':
		case 'crud.edit':
		case 'crud.set_price':

		    $scope.title = items.title;
		 	$scope.services = [];
	        $scope.allServices = []; 
			$scope.ErrorDisplay = "none"; 
			$scope.LoadingDisplay = "none";
			$scope.LoadingMsg = ""; 
			$scope.model ={}; 
			$scope.parentService = true;
			$scope.parentServiceText = "";

			var CurrentServicePrices = [];	

			$scope.priceList = [];



			var service_breadcrumb = [];

		    var parentServiceText = function(str){

		    	str = str.split('>');
	 
		    	return str.join('<i class="fa fa-caret-right red" aria-hidden="true"></i>')

		    } 


			var serviceFinder = function(pid){

				if(pid!="0"){  

					parentItem = new jsonFinder(allServices).findby("id").val(pid).data;

					parentItem_parent_id = parentItem.data.parent_id;

					service_breadcrumb[service_breadcrumb.length] = parentItem.data.service_name; 							

					serviceFinder(parentItem_parent_id);

				}


			}

			var getEmptyRow = function(){

					return { id:0,service_id:currenctService.id,unit_id:currenctService.unit.id,customer_price:0,third_party_price:0,qty:0 ,canDelete : false};

			}


			var savePriceCallback = function(_data){

							Error.off();

			        		Loading.off(); 

			        		Res = new Response(_data);

							if(Res.isOk()){
 
								 loadServicePrices();
								
							}
							else{

								Error.set(Res.Msg());

							}

			}
			
			$scope.savePrice = function(SaveData){

 				if(SaveData.id){

 					Services.UpdateServicePrice(SaveData,SaveData.id).success(savePriceCallback).error(function(er){ });

 				}
 				else{

 					Services.SaveServicePrice(SaveData).success(savePriceCallback).error(function(er){ });

 				}

			}

			$scope.addMoreUnit = function(){

				$scope.priceList[$scope.priceList.length] = getEmptyRow();

			}

			var loadServicePrices = function(){

				Services.getServicePrice().success(function(_data){

					if(_data.status == "done"){

						currenctService = items.currenctService;

						$scope.ServicePrices = _data.data;

						var dt  = jsonFinder($scope.ServicePrices).findAll("service_id").val(items.currenctService.id);
  
						if(dt.result){

							CurrentServicePrices = dt.data;

							for(var i in CurrentServicePrices){

								CurrentServicePrices[i].canDelete = false;

							}

						}
						else{

							CurrentServicePrices = [];

						}

						if(CurrentServicePrices.length == 0){

							 $scope.addMoreUnit();

						}
						else{

							$scope.priceList = CurrentServicePrices; $scope.addMoreUnit();
 
						}

					}

				});

			}

			 
			$scope.LoadServices  = function(){

				Services.List().success(function(_data){

		        	if(_data.status == "done"){

		        		$scope.allServices = _data.data;
	 					
	 					$scope.services = new jsonFinder($scope.allServices).findAll("parent_id").val("0").data ;

		        		if(items.data){

		        			//$scope.model.frmHubCompany = String(items.data.parent_id);

		        		}
		        		
		        	}

		        }).error(function(er){


		        });

	        }


        	var Error = {};

	        Error.set = function(data){   

				$scope.ErrorDisplay = "block";
				$scope.Error = data ; 

			}

			Error.off = function(){

					$scope.ErrorDisplay = "none";
					$scope.Error = "" ; 

			}

			var Loading = {};
			
			$scope.OpenedId = 0;

			$scope.loadFields = function(){

	        	filds =   {

	        				"service_id":_(items.currenctService.id),
							"unit_id":_($scope.model.frmUnits),
							"qty_increment":_($scope.model.frmQuantityIncrement	),
							 
				};

				return filds;
	        }

	        $scope.deletePriceConfirm = function(deleteRowIndex){


	        		$scope.priceList[deleteRowIndex].canDelete = true; 
  
 

	        }

	        $scope.deletePrice = function(deleteRowIndex){


	        		Delete($scope.priceList[deleteRowIndex].id );
 

	        } 

			var ClearForm = function(){

				if(items.option == "crud.set_price"){

					if(items.currenctService){

						loadServicePrices();

						if(items.currenctService.unit){

						    $scope.parentServiceText = parentServiceText(items.currenctService.names);
	  				 
							$scope.unit_name = items.currenctService.unit.unit_name;


						}
						

					}


				}
				else{
				
					$scope.model.frmUnits = "0"; 
					$scope.model.frmQuantityIncrement = "-1";

					if(items.currenctService){

						$scope.parentServiceText = parentServiceText(items.currenctService.names);
	  					
	  					if(items.currenctService.unit){

		  					_data =  items.currenctService.unit;

	  						$scope.OpenedId = _data.id;

							$scope.model.frmUnits = String(_data.unit_id); 
							$scope.model.frmQuantityIncrement = String(_data.qty_increment);

						}

					}
				}

				$scope.formStatus = "block";
	        	
	        	Error.off(); 

			}

			ClearForm();

			Common.getStates().success(function(res){

				Res = new Response(res);

	        	if(Res.isOk()){

	        		$scope.states = res.data;


	        		if(items.data)
	        		$scope.model.frmHubState = items.data.state;

	        		 
	        	}

	        });


			Loading.set = function(data){   

					$scope.LoadingDisplay = "block";
					$scope.LoadingMsg = data ; 

			}

			Loading.off = function(){

					$scope.LoadingDisplay = "none";
					$scope.LoadingMsg = "" ; 

			}

			var saveCallback = function(_data){

							Error.off();

			        		Loading.off(); 

			        		Res = new Response(_data);

							if(Res.isOk()){
 
								 $uibModalInstance.close('saved');
								
							}
							else{

								Error.set(Res.Msg());

							}

			        	}

			  
			$scope.save = function(){

						filds = $scope.loadFields();

						Loading.set("Saving..");

			        	
			 
			        	if($scope.OpenedId != 0){

								Services.UpdateServiceUnit(filds,$scope.OpenedId).success(saveCallback).error(function(er){ });

			        	}
			        	else{

								Services.SaveServiceUnit(filds).success(saveCallback).error(function(er){ });
			        	
			        	}


			}  


					LoadUnits();
	        

		break;

		case 'crud.delete':

			

		break;

	}

});

FHMOD.controller("ManageServicesPrices",function($scope,Services,Common,$location,$uibModal,Units){
		  

		$scope.msg = ""; 
        
		$scope.crud = {};

		$scope.model = {};

		$scope.services = [];

		$scope.allServices = [];

		$scope.services_grouped_format = [];

		$scope.service_units = [];

		$scope.Units = [];

		var LoadUnits = function(){

			Units.List().success(function(_data){

				if(_data.status == "done"){

					$scope.Units = _data.data;

					$scope.Load();

				}

			})

		}

		LoadUnits();
 	
 	    $scope.getSubServices = function(id){
 
	 				return new jsonFinder($scope.allServices).findAll("parent_id").val(id).data ;
		}
 
        $scope.crud.new = function(currenctService){

				         	
        	    var ModalWindow_New = $uibModal.open({

					templateUrl : 'form.html',
					controller: 'ManageServicesPricesModal',
					resolve: {
						items:function(){
							return {
								option:'crud.new',
								title:'Configure Units And Prices',
								serviceData : $scope.services,
								currenctService:currenctService

							}
						}
					}

				});


				ModalWindow_New.result.then(function(opt){

						if(opt == "saved"){ $scope.Load();}

				},function(){});


        }

        $scope.crud.setPrice = function(currenctService){

				         	
        	    var ModalWindow_SetPrice = $uibModal.open({

					templateUrl : 'price_form.html',
					controller: 'ManageServicesPricesModal',
					resolve: {
						items:function(){
							return {
								option:'crud.set_price',
								title:'Configure Prices',
								serviceData : $scope.services,
								currenctService:currenctService

							}
						}
					}

				});


				ModalWindow_SetPrice.result.then(function(opt){

						if(opt == "saved"){ $scope.Load();}

				},function(){});


        }	 
		
		$scope.crud.delete = function(Id,$event){

			var dt = jsonFinder($scope.allServices).findby("id").val(Id);

			$scope.msg =["Are you sure want to delete '"+dt.data.data.service_name+"' ? "];

		    var modalInstance = $uibModal.open({
						      
		      animation: true,
		      templateUrl: 'alert.html',
		      controller:'ManageServicesModal',
		      resolve: {

		      	 items:function(){

		      	 	return $scope.msg;

		      	 }

		      }

		    });

		    modalInstance.result.then(function(opt){

		    	Delete(Id);

		    },function(){});
 
			 
        	StopEventBubling($event);

        }
 
        $scope.open = function(id){   
 
        	var editRow = new jsonFinder($scope.allServices).findby("id").val(id) ;

        	if(editRow.result){

        		allServices = $scope.allServices;

				var ModalWindow_Edit = $uibModal.open({

						templateUrl : 'form.html',
						controller: 'ManageServicesModal',
						resolve: {
							items:function(){
								return {
									option:'crud.new',
									title:'Modify Service Details',
									data:editRow.data.data,
									parent_id:editRow.data.data.parent_id
								}
							}
						}

				});     
				
				ModalWindow_Edit.result.then(function(opt){

					 if(opt == "saved"){ $scope.Load();}

				},function(){});

			}   	 

        }
 
        $scope.getStatus = function(status){

        	return Status(status);

        }

        $scope.setStatus = function(state,$event){

        	StopEventBubling($event);



        }
         

		var Delete = function(Id){

			var dt = jsonFinder($scope.allServices).findby("id").val(Id);
 
			if(dt.result){

				Services.delete(Id).success(function(_data){

  					if(_data.status == "done"){

	  					var i = dt.data.index;
	 
						$scope.allServices.splice(i,1);


  					}
					 
				});
 
			}

        }

			 

        $scope.Load = function(){

			Services.List().success(function(_data){

	        	if(_data.status == "done"){

	        		$scope.allServices = _data.data;
 
 					$scope.services = new jsonFinder($scope.allServices).findAll("parent_id").val("0").data ;

 					$scope.loadServicesGrouped();

 					
 					
	        	}

	        }).error(function(er){


	        });

        }

        $scope.loadServiceUnits = function(){

        	Services.ServiceUnitList().success(function(_data){

 				if(_data.status == "done"){

 					$scope.service_units  = _data.data;

 					BulidList();


 				}

        	})

        }

	    $scope.loadServicesGrouped = function(){

	    	Services.List_grouped().success(function(data){
 				
 				if(data.status == "done"){

 					$scope.services_grouped_format  = data.data;

					

 					$scope.loadServiceUnits();

 				}

	    	});

	    }
 
	    var BulidList = function(){

	    	for(var i in $scope.services){

	    		$scope.services[i].subServices =  getSubServicesGroupedFormat($scope.services[i].id);

	    	}

	    } 

	    var BulidListWithUnits = function(){

	    	for(var i in $scope.services){

	    		$scope.services[i].subServicesUnits =  getSubServicesUnit($scope.services[i].subServices);

	    	}

	    } 

	    $scope.BindingHtml = function(str){


	    	str = str.split('>');
 
	    	return str.join('<i class="fa fa-caret-right red" aria-hidden="true"></i>')

	    } 

	    var getSubServicesGroupedFormat = function(id){

	    	var returnArray = [];

	    	for(var i in $scope.services_grouped_format){

	    		if($scope.services_grouped_format[i].serviceNamesIds.length > 0){
 					 
	    			 if($scope.services_grouped_format[i].serviceNamesIds[0] == id){

	    			 		ln = returnArray.length; 

	    			 		returnArray[ln] = {id:$scope.services_grouped_format[i].id,names:$scope.services_grouped_format[i].serviceNames,unit:getSubServicesUnit($scope.services_grouped_format[i].id)} ;
	    
	    			 }

	    		}

	    	}
 
	    	return returnArray;

	    }

	    var getSubServicesUnit = function(id){

	    	for(var i in $scope.service_units){
 
				if($scope.service_units[i].service_id == id){

					 for( var j in $scope.Units ){ 

					 		if($scope.Units[j].id == $scope.service_units[i].unit_id){

					 			$scope.service_units[i].unit_name = $scope.Units[j].unit_name;
				
								return $scope.service_units[i];

					 		}

					 }			 	 

 
	    		}


	    	}
 
	    	

	    	return null;
  
	    }

 

});