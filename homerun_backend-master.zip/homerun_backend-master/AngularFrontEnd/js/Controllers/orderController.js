FHMOD.controller("ManageOrders",function($scope){

        $scope.Orders = Orders;

        $scope.Services = Services;

        $scope.CurrentOrder = [];

        $scope.CurrentService = [];

        $scope.orderDisplay = "block";

        $scope.serviceDisplay = "none";

        $scope.CurrentOrder = "";

        $scope.CurrentServiceLineItems = [];

        $scope.openServiceDetails = function(arg){

            $scope.CurrentOrderI = arg;
            $scope.orderDisplay = "none";
            $scope.serviceDisplay = "block";

            $scope.CurrentOrder = [];

            for( var i = 0 ; i < $scope.Services.length;i++) {
                if($scope.Services[i].OrderId == $scope.CurrentOrderI) {

                     $scope.CurrentOrder[$scope.CurrentOrder.length] = $scope.Services[i];

                }

            }

        }


        $scope.openServiceLineItemDetails = function(servId){

            $scope.CurrentService = $scope.CurrentOrder[servId];
            $scope.CurrentServiceLineItems = $scope.CurrentService["ServiceLineItems"];

            angular.element('#serviceDetailsOpener').trigger("click");

        }

        $scope.BacktoOrders = function(){

            $scope.orderDisplay = "block";
            $scope.serviceDisplay = "none";

        }

});