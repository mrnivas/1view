// Modal Controllers

var allServices = [];

FHMOD.controller("ManageServicesModal",function($scope,$uibModalInstance,items,Common,Services){

	$scope.msg = items[0];

	$scope.ok = function(){

		$uibModalInstance.close("ok");

	}

	$scope.close = function(){

		$uibModalInstance.dismiss('cancel');

	}

	switch(items.option){

		case 'crud.new':
		case 'crud.edit':

		    $scope.title = items.title;
		 	$scope.services = [];
	        $scope.allServices = []; 
			$scope.ErrorDisplay = "none"; 
			$scope.LoadingDisplay = "none";
			$scope.LoadingMsg = ""; 
			$scope.model ={}; 
			$scope.parentService = false;			

			var service_breadcrumb = [];

			var serviceFinder = function(pid){

				if(pid!="0"){  


					parentItem = new jsonFinder(allServices).findby("id").val(pid).data;

					console.log(parentItem)


					parentItem_parent_id = parentItem.data.parent_id;

					service_breadcrumb[service_breadcrumb.length] = parentItem.data.service_name; 							

					serviceFinder(parentItem_parent_id);

				}


			}

			 
			$scope.LoadServices  = function(){

				Services.List().success(function(_data){

		        	if(_data.status == "done"){

		        		$scope.allServices = _data.data;
	 					
	 					$scope.services = new jsonFinder($scope.allServices).findAll("parent_id").val("0").data ;
 
	 					   

		        		if(items.data){

		        			//$scope.model.frmHubCompany = String(items.data.parent_id);

		        		}
		        		
		        	}

		        }).error(function(er){


		        });

	        }


        	var Error = {};

	        Error.set = function(data){   

				$scope.ErrorDisplay = "block";
				$scope.Error = data ; 

			}

			Error.off = function(){

					$scope.ErrorDisplay = "none";
					$scope.Error = "" ; 

			}

			var Loading = {};
			
			$scope.OpenedId = 0;

			$scope.loadFields = function(){


	        	filds =   {

	        				"service_name":_($scope.model.frmServiceName),
							"parent_id":_($scope.model.frmServiceParent),
							"status":_($scope.model.frmServiceStatus),
							 
				};

				return filds;
	        }

			var ClearForm = function(){
 

				$scope.model.frmServiceName = "";
				$scope.model.frmServiceStatus = "";
				$scope.model.frmServiceParent = items.parent_id; 


				if(items.parent_id!="0"){

						serviceFinder(items.parent_id);
 						
						if(service_breadcrumb.length > 0){

								service_breadcrumb.reverse();
 
								$scope.parentService = true;

								$scope.parentServiceText = service_breadcrumb.join(' <i class="fa fa-caret-right red" aria-hidden="true"></i> ');								 							

						}


				}

				if(items.data){
 
					_data = items.data;

					 
					$scope.OpenedId = _data.id;
					$scope.model.frmServiceParent = items.parent_id;	 
					$scope.model.frmServiceName = _data.service_name;
					$scope.model.frmServiceStatus = String(_data.status); 


				}

				$scope.formStatus = "block";
	        	
	        	Error.off();
	        	 

			}

			ClearForm();

			Common.getStates().success(function(res){

				Res = new Response(res);

	        	if(Res.isOk()){

	        		$scope.states = res.data;


	        		if(items.data)
	        		$scope.model.frmHubState = items.data.state;

	        		 
	        	}

	        });


			Loading.set = function(data){   

					$scope.LoadingDisplay = "block";
					$scope.LoadingMsg = data ; 

			}

			Loading.off = function(){

					$scope.LoadingDisplay = "none";
					$scope.LoadingMsg = "" ; 

			}

			  
			$scope.save = function(){

						filds = $scope.loadFields();

						Loading.set("Saving..");

			        	var saveCallback = function(_data){

							Error.off();

			        		Loading.off();
			        		
			        		console.log(_data);

			        		Res = new Response(_data);

							if(Res.isOk()){
 
								 $uibModalInstance.close('saved');
								
							}
							else{

								Error.set(Res.Msg());

							}

			        	}
			 
			        	if($scope.OpenedId != 0){

								Services.update(filds,$scope.OpenedId).success(saveCallback).error(function(er){ });

			        	}
			        	else{

								Services.Save(filds).success(saveCallback).error(function(er){ });
			        	}


					}  


					//$scope.LoadServices();
	        

		break;

		case 'crud.delete':

		break;

	}

});

FHMOD.controller("ManageServices",function($scope,Services,Common,$location,$uibModal){
		  

		$scope.msg = ""; 
        
		$scope.crud = {};

		$scope.model = {};

		$scope.services = [];

		$scope.allServices = [];
 	
 	    $scope.getSubServices = function(id){
 
	 				return new jsonFinder($scope.allServices).findAll("parent_id").val(id).data ;
		}
 
        $scope.crud.new = function(parent_id){
 
	        	allServices = $scope.allServices;
				         	
        	    var ModalWindow_New = $uibModal.open({

					templateUrl : 'form.html',
					controller: 'ManageServicesModal',
					resolve: {
						items:function(){
							return {
								option:'crud.new',
								title:'Create New Service',
								parent_id:parent_id
							}
						}
					}

				});


				ModalWindow_New.result.then(function(opt){

						if(opt == "saved"){ $scope.Load();}

				},function(){});


        }

	 
		
		$scope.crud.delete = function(Id,$event){

			var dt = jsonFinder($scope.allServices).findby("id").val(Id);

			$scope.msg =["Are you sure want to delete '"+dt.data.data.service_name+"' ? "];

		    var modalInstance = $uibModal.open({
						      
		      animation: true,
		      templateUrl: 'alert.html',
		      controller:'ManageServicesModal',
		      resolve: {

		      	 items:function(){

		      	 	return $scope.msg;

		      	 }

		      }

		    });

		    modalInstance.result.then(function(opt){

		    	Delete(Id);

		    },function(){});
 
			 
        	StopEventBubling($event);

        }
 
        $scope.open = function(id){   
 
        	var editRow = new jsonFinder($scope.allServices).findby("id").val(id) ;

        	if(editRow.result){

        		allServices = $scope.allServices;

				var ModalWindow_Edit = $uibModal.open({

						templateUrl : 'form.html',
						controller: 'ManageServicesModal',
						resolve: {
							items:function(){
								return {
									option:'crud.new',
									title:'Modify Service Details',
									data:editRow.data.data,
									parent_id:editRow.data.data.parent_id
								}
							}
						}

				});     
				
				ModalWindow_Edit.result.then(function(opt){

					 if(opt == "saved"){ $scope.Load();}

				},function(){});

			}   	 

        }
 
        $scope.getStatus = function(status){

        	return Status(status);

        }

        $scope.setStatus = function(state,$event){

        	StopEventBubling($event);



        }
         

		var Delete = function(Id){

			var dt = jsonFinder($scope.allServices).findby("id").val(Id);
 
			if(dt.result){

				Services.delete(Id).success(function(_data){

  					if(_data.status == "done"){

	  					var i = dt.data.index;

	  					if(dt.data.data.parent_id == 0){

	  						$scope.services.splice(i,1);

	  					}
	  					else{

	  						$scope.allServices.splice(i,1);

	  					}
						 
  					}
					 
				});
 
			}

        }

			 

        $scope.Load = function(){

			Services.List().success(function(_data){

	        	if(_data.status == "done"){

	        		$scope.allServices = _data.data;

 					$scope.services = new jsonFinder($scope.allServices).findAll("parent_id").val("0").data ;
 					
	        	}

	        }).error(function(er){


	        });

        }

 

		$scope.Load();
 

});