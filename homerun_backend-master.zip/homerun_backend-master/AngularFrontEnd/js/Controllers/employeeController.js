FHMOD.controller("ManageEmployeesModels",function($scope,$uibModalInstance,items,Common,Employee,$filter){


			$scope.ok = function(){

				$uibModalInstance.close("ok");

			}

			$scope.close = function(){

				$uibModalInstance.dismiss('cancel');

			}

			switch(items.option){

				case 'crud.new':
				case 'crud.edit':



				    $scope.title = items.title;
				 	$scope.Companies = [];
			        $scope.Hubs = [];
					$scope.states = [];
					$scope.ErrorDisplay = "none"; 
					$scope.LoadingDisplay = "none";
					$scope.LoadingMsg = ""; 
					$scope.model ={};

					$scope.format = 'dd-MM-yyyy';
 
					$scope.dojStatus = false;
 
					$scope.doj = {
						opened : false
					};
					 
					$scope.doj =  null;					  

					$scope.dateOptions = { 
					    formatYear: 'yy',
					    maxDate: new Date().setDate(( new Date().getDate() + (4 * 365 ) )), 
					    startingDay: 1
					};

					$scope.dojpick = function() {

					    $scope.doj.opened = true;  

					};

					$scope.dobpick = function() {
					    $scope.dob.opened = true;
					};

					$scope.format = "dd-MM-yyyy"; 

					$scope.doj = {
					    opened: false
					};

					$scope.dob = {
					    opened: false
					};
		  
					$scope.submit = function(){

						$uibModalInstance.close('save');

					}
					  
					$scope.cancel = function(){

						$uibModalInstance.dismiss();

					}
					

		        	var Error = {};

			        Error.set = function(data){   

						$scope.ErrorDisplay = "block";
						$scope.Error = data ; 

					}

					Error.off = function(){

							$scope.ErrorDisplay = "none";
							$scope.Error = "" ; 

					}

					var Loading = {};
					
					$scope.OpenedId = 0;

					$scope.loadFields = function(){

						var DOB = $scope.model.dob.getDate()+"-"+($scope.model.dob.getMonth()+1)+"-"+$scope.model.dob.getFullYear();
						var DOJ = $scope.model.doj.getDate()+"-"+($scope.model.doj.getMonth()+1)+"-"+$scope.model.doj.getFullYear();
						 

						filds = { 

							employee_first_name:$scope.model.frmEmployeeFirstName,
							employee_last_name:$scope.model.frmEmployeeLastName,
							employee_code:$scope.model.frmEmployeeCode,
							emplayee_gender:$scope.model.frmEmployeeGender,
							dob:DOB,
							doj:DOJ,   
							status:$scope.model.frmEmployeeStatus,
							address:$scope.model.frmEmployeeAddress,
							phone:$scope.model.frmEmployeePhone,
							email:$scope.model.frmEmployeeEmail,
							city:$scope.model.frmEmployeeCity,
							state:$scope.model.frmEmployeeState,
							pincode:$scope.model.frmEmployeePincode 

						}
 
						return filds;

			        }

					var ClearForm = function(){


						$scope.model.frmEmployeeFirstName = "";
						$scope.model.frmEmployeeLastName="";
						$scope.model.frmEmployeeCode="";
						$scope.model.frmEmployeeGender="";
						$scope.model.dob="";
						$scope.model.doj="";   
						$scope.model.frmEmployeeStatus="";
						$scope.model.frmEmployeeAddress="";
						$scope.model.frmEmployeePhone="";
						$scope.model.frmEmployeeEmail="";
						$scope.model.frmEmployeeCity="";
						$scope.model.frmEmployeeState="";
						$scope.model.frmEmployeePincode ="";

						if(items.data){
		 
							_data = items.data;

							$scope.OpenedId = _data.id;

							var dobSplit = _data.dob.split('-'); 
							var dobOb = new Date(dobSplit[2]+"-"+dobSplit[1]+"-"+dobSplit[0]);

							var dojSplit = _data.doj.split('-'); 
							var dojOb = new Date(dojSplit[2]+"-"+dojSplit[1]+"-"+dojSplit[0]);

							$scope.model.frmEmployeeFirstName = _data.employee_first_name;
							$scope.model.frmEmployeeLastName= _data.employee_last_name;
							$scope.model.frmEmployeeCode= _data.employee_code;
							$scope.model.frmEmployeeGender= _data.gender;
							$scope.model.dob= dobOb, 
							$scope.model.doj= dojOb,   
							$scope.model.frmEmployeeStatus=String(_data.status);
							$scope.model.frmEmployeeAddress=_data.address;
							$scope.model.frmEmployeePhone=_data.phone;
							$scope.model.frmEmployeeEmail=_data.email;
							$scope.model.frmEmployeeCity=_data.city;

							$scope.model.frmEmployeePincode =_data.pincode;

						}

						$scope.formStatus = "block";
			        	
			        	Error.off();
			        	 

					}

					ClearForm();

					Common.getStates().success(function(res){

						Res = new Response(res);

			        	if(Res.isOk()){

			        		$scope.states = res.data;


			        		if(items.data)
			        		$scope.model.frmEmployeeState = items.data.state;
 
			        	}

			        });


					Loading.set = function(data){   

							$scope.LoadingDisplay = "block";
							$scope.LoadingMsg = data ; 

					}

					Loading.off = function(){

							$scope.LoadingDisplay = "none";
							$scope.LoadingMsg = "" ; 

					}

					  
					$scope.save = function(){

								filds = $scope.loadFields();

								Loading.set("Saving..");

					        	var saveCallback = function(_data){

									Error.off();

					        		Loading.off();
					        		
					        		console.log(_data);

					        		Res = new Response(_data);

									if(Res.isOk()){
		 
										 $uibModalInstance.close('saved');
										
									}
									else{

										Error.set(Res.Msg());

									}

					        	}
					 
					        	if($scope.OpenedId != 0){
		 

										filds.address_id =  items.data.address_id;

										Employee.update(filds,$scope.OpenedId).success(saveCallback).error(function(er){ });

					        	}
					        	else{

										Employee.Save(filds).success(saveCallback).error(function(er){ });
					        	}


							}  
			        

				break;

				case 'crud.delete':

						$scope.title = items.title;
						$scope.msg = "Are you sure want to delete?"

				break;

			}

 
			


});

FHMOD.controller("ManageEmployees",function($scope,$uibModal,Common,$location,Employee){
   		
		$scope.Employees = [];

 		$scope.crud = {

 			new : function(){

 				var ModalWindowForNew = $uibModal.open({

 					templateUrl : 'form.html',
 					controller : 'ManageEmployeesModels',
 					size:'lg',
 					resolve : {

 						items : function(){

 							return { option : 'crud.new',
 									 title  : 'Create Employee' }

 						}

 					}
 				}); 			 

 			},

 			edit : function(id){

				var editRow = new jsonFinder($scope.Employees).findby("id").val(id) ;

				if(editRow.result){

					var ModalWindow_Edit = $uibModal.open({

						templateUrl : 'form.html',
						controller  : 'ManageEmployeesModels',
						size:'lg',
						resolve: {
							items:function(){
								return {
									option:'crud.edit',
									title:'Employee Moddification | EMP CODE : '+  editRow.data.data.employee_code +' | UDS CODE : '+editRow.data.data.uds_employee_code,
									data:editRow.data.data
								}
							}
						}

					});

				}

				ModalWindow_Edit.result.then(function(opt){

						if(opt == "saved"){ $scope.LoadEmployees();}

				},function(){});


			},


			delete : function(id){

				 var deleteRow = new jsonFinder($scope.Employees).findby("id").val(id) ;

				 if(deleteRow.result){

					 var ModalWindow_Delete = $uibModal.open({

						templateUrl : 'alert.html',
						controller: 'ManageEmployeesModels',
						resolve: {
							items:function(){
								return {
									option:'crud.delete',
									title:'Delete Confirmation "'+ deleteRow.data.data.employee_first_name +'"'
								}
							}
						}

					 });

					 ModalWindow_Delete.result.then(function(opt){

				    	 if(opt == "ok"){
 
				    	 	 Employee.delete(deleteRow.data.data.id).success(function(_data){

				    	 	 		 if(_data.status == "done"){

				    	 	 		 	 $scope.Employees.splice(deleteRow.data.index,1);

				    	 	 		 }

				    	 	 })

				    	 }

				     },function(){});


				}

			}

 		}

 		$scope.LoadEmployees = function(){

			Employee.List().success(function(_data){

	        	if(_data.status == "done"){

	        		$scope.Employees = _data.data;
	        		
	        	}

	        }).error(function(er){


	        });

        }

        $scope.LoadEmployees();
		

});
