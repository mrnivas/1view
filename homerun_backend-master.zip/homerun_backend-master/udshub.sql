/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50542
Source Host           : localhost:3306
Source Database       : udshub

Target Server Type    : MYSQL
Target Server Version : 50542
File Encoding         : 65001

Date: 2016-08-12 20:09:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `uds_hub_master_addresses`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_addresses`;
CREATE TABLE `uds_hub_master_addresses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `contact_person_name` varchar(255) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `pincode` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_person_phone` varchar(45) DEFAULT NULL,
  `address_type` enum('COMPANY','HUB','PERSON') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uds_hub_master_addresses
-- ----------------------------
INSERT INTO `uds_hub_master_addresses` VALUES ('1', 'test, test', 'Rammohan Tangirala', 'Chennai', 'TAMIL NADU', '611109', '123456', 'rammohan@uds.com', '123456789', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('57', 'Test', 'sdfsf', 'sdf', 'HARYANA', '1232', '123456', 'testt@gd.com', '123456', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('58', 'Test', 'sdfsf2', 'sdf', 'RAJASTHAN', '1232', '123456', 'testt@gd.com', '123456', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('59', 'tNagar', 'NIavs', 'sdf', 'undefined', '324', '787', 'sr@gm.cim', '3234', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('60', 'SDFGD', 'asd', 'xdf', 'undefined', '123', 'df', 'sdfgf@sdf.sdf', '123', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('61', 'ert', '345', 'dfg', 'undefined', '345', '345', 'dfg@gfr.ghy', '345', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('62', 'sfg', 'dfg', 'dfg', 'undefined', '456', '434', 'dfg@gfh.fgh', '132132', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('63', 'sdfsd', 'asdfsd', 'sdfsf', 'undefined', '12313', '12321', 'sdsfd@sdf.sdf', '12321', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('64', 'sdfsdf', 'asddd', 'sdf', 'undefined', '123', '232', 'sdfsdf@sdf.sdf', '123', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('65', 'sdfsd', 'asd', 'asd', 'undefined', '12', '123', 'asd@df.ff', '12123', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('66', 'undefined', 'undefined', 'undefined', 'undefined', '345', 'undefined', 'dfgf@er.iio', 'undefined', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('67', 'fdfs', 'sdfs', 'sdf', 'undefined', '123', '131', 'sdfsd@sdf.sdf', '54', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('68', 'fghfgh', 'fghfgh', 'dfgdfg', 'undefined', '45345', 'fghfgh', 'dfgdfg@sdg.fgf', 'fghfgh', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('69', '', 'dfgdfg', 'dfgdfg', 'undefined', '131312', '', 'mrsdf@dfgd.dfg', 'ertert', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('70', '', 'dfgdfg', 'dfgdfg', 'undefined', '131312', 'ertert', 'mrsdf@dfgd.dfg', 'ertert', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('71', '', 'dfgdfg', 'dfgdfg', 'undefined', '131312', 'ertert', 'mrsdf@dfgd.dfg', 'ertert', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('72', 'asd', 'sdsdf', 'sdf', 'ANDHRA PRADESH', '232', '332', 'asdfsdf@sdfsd.sdf', '23', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('73', 'test', 'dfs', 'sdfs', 'DELHI', '32423', '234', 'xcbnmnb@sdfsd.sdf', '23423', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('74', 'sad', 'sad', 'ss', 'ANDAMAN  NICOBAR', '213', '8090', 'sasd@dcd.sd', 'ds', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('75', 'SSDFK', 'ASDASD', 'ASDAS', 'ANDAMAN  NICOBAR', '12356', 'SDASHD', 'SAHAS@SDFS.SDF', 'ASSD', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('76', 'ZX', '23423', 'sfdfs', 'JHARKHAND', '2325', 'ZX', 'zxz@xcv.lp', 'sdf', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('77', '', 'sad', 'dasd', 'ANDAMAN  NICOBAR', '234234', '', 'qweqwe@werwet.uiyu', '323423', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('78', 'sdfs', 'asd', 'sdfsd', 'ANDAMAN  NICOBAR', '23423', '234', 'tst@sdf.com', 'sdf', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('79', 'sdfs', 'asd', 'sdfsd', 'ANDAMAN  NICOBAR', '23423', '234', 'tst@sdf.com', 'sdf', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('80', 'tetst', '709808', 'chennai', 'ANDAMAN  NICOBAR', '2198', '123', 'test@tes.xom', '8908', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('81', 'tetst', '709808', 'chennai', 'ANDAMAN  NICOBAR', '2198', '123', 'test@tes.xom', '8908', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('82', 'tetst', '709808', 'chennai', 'ANDAMAN  NICOBAR', '2198', '123', 'test@tes.xom', '8908', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('83', 'tetst', '709808', 'chennai', 'ANDAMAN  NICOBAR', '2198', '123', 'test@tes.xom', '8908', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('84', 'tetst', '709808', 'chennai', 'ANDAMAN  NICOBAR', '2198', '123', 'test@tes.xom', '8908', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('85', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('86', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('87', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('88', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('89', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('90', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('91', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('92', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('93', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('94', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('95', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('96', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('97', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('98', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('99', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('100', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('101', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('102', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('103', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('104', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('105', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('106', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('107', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('108', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('109', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('110', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('111', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('112', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('113', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('114', 'sdfsdf', '43645', 'dfgdfg', 'GOA', '45345', '3243', 'sds@fdgm.jkkl', '54365', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('115', 'SD', 'jhj', 'bsas', 'ANDAMAN  NICOBAR', '1228', '7889', 'bnsd@dbdf.fvdf', '7880998', 'HUB');
INSERT INTO `uds_hub_master_addresses` VALUES ('116', 'SD', 'jhj', 'bsas', 'ANDAMAN  NICOBAR', '1228', '7889', 'bnsd@dbdf.fvdf', '7880998', 'HUB');
INSERT INTO `uds_hub_master_addresses` VALUES ('117', 'cxvb', 'gfg', 'ffghfgh', 'ASSAM', '564564', 'cvbcv', 'cvbcv@ef.uj', '324564', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('118', 'cxvb', 'gfg', 'ffghfgh', 'ASSAM', '564564', 'cvbcv', 'cvbcv@ef.uj', '324564', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('119', 'cxvb', 'gfg', 'ffghfgh', 'ASSAM', '564564', 'cvbcv', 'cvbcv@ef.uj', '324564', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('120', 'cxvb', 'gfg', 'ffghfgh', 'ASSAM', '564564', 'cvbcv', 'cvbcv@ef.uj', '324564', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('121', 'cxvb', 'gfg', 'ffghfgh', 'ASSAM', '564564', 'cvbcv', 'cvbcv@ef.uj', '324564', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('122', 'sdfsd', '23423', 'ddf', 'ARUNACHAL PRADESH', '43234', '2342', 'dfgdfg@sdf.sdf', '23423', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('123', 'sdfsd', '23423', 'ddf', 'ARUNACHAL PRADESH', '43234', '2342', 'dfgdfg@sdf.sdf', '23423', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('124', 'sfsfd', 'werwe', 'fgff', 'ANDAMAN  NICOBAR', '45', '2423', 'ggf@efre.lj', '35434', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('125', 'sfsfd', 'werwe', 'fgff', 'ANDAMAN  NICOBAR', '45', '2423', 'ggf@efre.lj', '35434', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('126', 'asdd', 'fdf', 'asd', 'ANDAMAN  NICOBAR', '42342', '23423', 'ssdsv@fdfgggj.ld', '144', 'HUB');
INSERT INTO `uds_hub_master_addresses` VALUES ('127', 'sdfsd', 'gfv', 'thfgf', 'ANDAMAN  NICOBAR', '234566', '3242', 'sdfsd@rtrhf.ujhgf', '456', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('128', 'sdfsd', 'gfv', 'thfgf', 'ANDAMAN  NICOBAR', '234566', '3242', 'sdfsd@rtrhf.ujhgf', '456', 'COMPANY');
INSERT INTO `uds_hub_master_addresses` VALUES ('129', 'ewf', 'fsdvvtre', 'fbvvxzxz', 'DELHI', '2465765', '2342', 'vdfrtf@hj.kjh', '23422', 'HUB');
INSERT INTO `uds_hub_master_addresses` VALUES ('130', 'wqwe', 'fdf', 'bvvc', 'GUJRAT', '56', '32423', 'vdfgdfb@edf.kkjh', '44', 'HUB');
INSERT INTO `uds_hub_master_addresses` VALUES ('131', 'sadsd', 'df', 'qweqw dfs we', 'ANDAMAN  NICOBAR', '234234', '21312', 'sdfsd@sdfss.ijh', '54', 'HUB');

-- ----------------------------
-- Table structure for `uds_hub_master_company_hub`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_company_hub`;
CREATE TABLE `uds_hub_master_company_hub` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `company_hub_name` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `company_logo` varchar(255) DEFAULT NULL,
  `company_code` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_type` enum('REGISTERED','CREATED') DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `address_id` bigint(20) DEFAULT NULL,
  `is_primary` int(11) DEFAULT NULL,
  `company_type` enum('COMPANY','HUB') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uds_hub_master_company_hub
-- ----------------------------
INSERT INTO `uds_hub_master_company_hub` VALUES ('1', 'UDS', '1', 'http://localhost:8387/AppImage/udslogo.png', 'UDSCOMP00001', '2016-07-28 19:30:57', 'CREATED', '1', '0', '1', '0', 'COMPANY');
INSERT INTO `uds_hub_master_company_hub` VALUES ('32', 'Fhapl2', '1', null, 'UDSCNY0000000032', '2016-07-20 16:42:26', 'CREATED', '1', '0', '58', '0', 'COMPANY');
INSERT INTO `uds_hub_master_company_hub` VALUES ('103', 'asdas', '1', null, 'UDSHUB0000000103', '2016-08-01 18:16:41', 'CREATED', '1', '32', '130', '0', 'HUB');
INSERT INTO `uds_hub_master_company_hub` VALUES ('104', 'asdasd wwre', '0', null, 'UDSHUB0000000104', '2016-08-01 20:09:50', 'CREATED', '1', '32', '131', '0', 'HUB');

-- ----------------------------
-- Table structure for `uds_hub_master_company_hub_employees`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_company_hub_employees`;
CREATE TABLE `uds_hub_master_company_hub_employees` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(255) DEFAULT NULL,
  `emplayee_code` varchar(255) DEFAULT NULL,
  `uds_employee_code` varchar(255) DEFAULT NULL,
  `address_id` bigint(20) DEFAULT NULL,
  `employee_photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `employee_company_id` bigint(20) DEFAULT NULL,
  `employee_hub_id` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `employee_service_type` varchar(45) DEFAULT NULL,
  `employee_service_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uds_hub_master_company_hub_employees
-- ----------------------------

-- ----------------------------
-- Table structure for `uds_hub_master_company_hub_services`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_company_hub_services`;
CREATE TABLE `uds_hub_master_company_hub_services` (
  `company_id` bigint(20) DEFAULT NULL,
  `service_id` bigint(20) DEFAULT NULL,
  UNIQUE KEY `unique` (`company_id`,`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uds_hub_master_company_hub_services
-- ----------------------------

-- ----------------------------
-- Table structure for `uds_hub_master_company_hub_users`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_company_hub_users`;
CREATE TABLE `uds_hub_master_company_hub_users` (
  `user_id` bigint(20) DEFAULT NULL,
  `company_id` bigint(20) DEFAULT NULL,
  `hub_id` bigint(20) DEFAULT NULL,
  UNIQUE KEY `uniqueIndex` (`user_id`,`company_id`),
  UNIQUE KEY `unique` (`user_id`,`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uds_hub_master_company_hub_users
-- ----------------------------
INSERT INTO `uds_hub_master_company_hub_users` VALUES ('8', '0', '0');
INSERT INTO `uds_hub_master_company_hub_users` VALUES ('28', '91', '0');
INSERT INTO `uds_hub_master_company_hub_users` VALUES ('29', '95', '0');
INSERT INTO `uds_hub_master_company_hub_users` VALUES ('30', '97', '0');
INSERT INTO `uds_hub_master_company_hub_users` VALUES ('31', '100', '0');

-- ----------------------------
-- Table structure for `uds_hub_master_services`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_services`;
CREATE TABLE `uds_hub_master_services` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(45) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uds_hub_master_services
-- ----------------------------
INSERT INTO `uds_hub_master_services` VALUES ('43', 'Plumbing', '0', '1');
INSERT INTO `uds_hub_master_services` VALUES ('44', 'Tap Wash basin And Sink', '43', '1');
INSERT INTO `uds_hub_master_services` VALUES ('45', 'Toilet And Sanitary Work', '43', '1');
INSERT INTO `uds_hub_master_services` VALUES ('46', 'Bathroom Fittings', '43', '1');
INSERT INTO `uds_hub_master_services` VALUES ('47', 'Blocks And Leackage', '43', '1');
INSERT INTO `uds_hub_master_services` VALUES ('48', 'Tap', '44', '1');
INSERT INTO `uds_hub_master_services` VALUES ('49', 'Wash Basin', '44', '1');
INSERT INTO `uds_hub_master_services` VALUES ('50', 'Kitchen Sink', '44', '1');
INSERT INTO `uds_hub_master_services` VALUES ('51', 'Others', '43', '-1');
INSERT INTO `uds_hub_master_services` VALUES ('52', 'Others', '44', '1');
INSERT INTO `uds_hub_master_services` VALUES ('53', 'Fitting And Installation', '48', '1');
INSERT INTO `uds_hub_master_services` VALUES ('54', 'Repair', '48', '1');
INSERT INTO `uds_hub_master_services` VALUES ('55', 'Fitting And Installation', '49', '1');
INSERT INTO `uds_hub_master_services` VALUES ('56', 'Repair', '49', '1');
INSERT INTO `uds_hub_master_services` VALUES ('57', 'Uninstallation', '49', '1');
INSERT INTO `uds_hub_master_services` VALUES ('58', 'Cleaning', '0', '1');
INSERT INTO `uds_hub_master_services` VALUES ('59', 'Uninstallation', '48', '-1');

-- ----------------------------
-- Table structure for `uds_hub_master_service_prices`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_service_prices`;
CREATE TABLE `uds_hub_master_service_prices` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_id` bigint(20) DEFAULT NULL,
  `unit_id` bigint(20) DEFAULT NULL,
  `customer_price` double DEFAULT NULL,
  `third_party_price` double DEFAULT NULL,
  `price_date` datetime DEFAULT NULL,
  `company_id` bigint(20) DEFAULT '0',
  `qty` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of uds_hub_master_service_prices
-- ----------------------------
INSERT INTO `uds_hub_master_service_prices` VALUES ('4', '53', '2', '2003', '150', '2016-08-11 20:46:44', '0', '1', '1');
INSERT INTO `uds_hub_master_service_prices` VALUES ('5', '45', '1', '2002', '1222', '2016-08-11 20:51:04', '0', '1', '-1');
INSERT INTO `uds_hub_master_service_prices` VALUES ('8', '53', '2', '200', '150', '2016-08-11 20:37:48', '0', '1', '1');

-- ----------------------------
-- Table structure for `uds_hub_master_service_units`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_service_units`;
CREATE TABLE `uds_hub_master_service_units` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_id` bigint(20) DEFAULT NULL,
  `unit_id` bigint(20) DEFAULT NULL,
  `qty_increment` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of uds_hub_master_service_units
-- ----------------------------
INSERT INTO `uds_hub_master_service_units` VALUES ('1', '45', '2', '0');
INSERT INTO `uds_hub_master_service_units` VALUES ('7', '46', '2', '0');
INSERT INTO `uds_hub_master_service_units` VALUES ('8', '47', '2', '0');
INSERT INTO `uds_hub_master_service_units` VALUES ('9', '50', '2', '0');
INSERT INTO `uds_hub_master_service_units` VALUES ('10', '52', '2', '0');
INSERT INTO `uds_hub_master_service_units` VALUES ('11', '53', '2', '1');
INSERT INTO `uds_hub_master_service_units` VALUES ('12', '54', '2', '1');
INSERT INTO `uds_hub_master_service_units` VALUES ('13', '55', '2', '1');
INSERT INTO `uds_hub_master_service_units` VALUES ('14', '56', '2', '1');
INSERT INTO `uds_hub_master_service_units` VALUES ('15', '57', '2', '1');

-- ----------------------------
-- Table structure for `uds_hub_master_state`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_state`;
CREATE TABLE `uds_hub_master_state` (
  `StateID` int(11) NOT NULL AUTO_INCREMENT,
  `CountryID` int(11) NOT NULL,
  `StateName` varchar(50) NOT NULL,
  PRIMARY KEY (`StateID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of uds_hub_master_state
-- ----------------------------
INSERT INTO `uds_hub_master_state` VALUES ('1', '1', 'ANDHRA PRADESH');
INSERT INTO `uds_hub_master_state` VALUES ('2', '1', 'ASSAM');
INSERT INTO `uds_hub_master_state` VALUES ('3', '1', 'ARUNACHAL PRADESH');
INSERT INTO `uds_hub_master_state` VALUES ('4', '1', 'GUJRAT');
INSERT INTO `uds_hub_master_state` VALUES ('5', '1', 'BIHAR');
INSERT INTO `uds_hub_master_state` VALUES ('6', '1', 'HARYANA');
INSERT INTO `uds_hub_master_state` VALUES ('7', '1', 'HIMACHAL PRADESH');
INSERT INTO `uds_hub_master_state` VALUES ('8', '1', 'JAMMU & KASHMIR');
INSERT INTO `uds_hub_master_state` VALUES ('9', '1', 'KARNATAKA');
INSERT INTO `uds_hub_master_state` VALUES ('10', '1', 'KERALA');
INSERT INTO `uds_hub_master_state` VALUES ('11', '1', 'MADHYA PRADESH');
INSERT INTO `uds_hub_master_state` VALUES ('12', '1', 'MAHARASHTRA');
INSERT INTO `uds_hub_master_state` VALUES ('13', '1', 'MANIPUR');
INSERT INTO `uds_hub_master_state` VALUES ('14', '1', 'MEGHALAYA');
INSERT INTO `uds_hub_master_state` VALUES ('15', '1', 'MIZORAM');
INSERT INTO `uds_hub_master_state` VALUES ('16', '1', 'NAGALAND');
INSERT INTO `uds_hub_master_state` VALUES ('17', '1', 'ORISSA');
INSERT INTO `uds_hub_master_state` VALUES ('18', '1', 'PUNJAB');
INSERT INTO `uds_hub_master_state` VALUES ('19', '1', 'RAJASTHAN');
INSERT INTO `uds_hub_master_state` VALUES ('20', '1', 'SIKKIM');
INSERT INTO `uds_hub_master_state` VALUES ('21', '1', 'TAMIL NADU');
INSERT INTO `uds_hub_master_state` VALUES ('22', '1', 'TRIPURA');
INSERT INTO `uds_hub_master_state` VALUES ('23', '1', 'UTTAR PRADESH');
INSERT INTO `uds_hub_master_state` VALUES ('24', '1', 'WEST BENGAL');
INSERT INTO `uds_hub_master_state` VALUES ('25', '1', 'DELHI');
INSERT INTO `uds_hub_master_state` VALUES ('26', '1', 'GOA');
INSERT INTO `uds_hub_master_state` VALUES ('27', '1', 'PONDICHERY');
INSERT INTO `uds_hub_master_state` VALUES ('28', '1', 'LAKSHDWEEP');
INSERT INTO `uds_hub_master_state` VALUES ('29', '1', 'DAMAN & DIU');
INSERT INTO `uds_hub_master_state` VALUES ('30', '1', 'DADRA & NAGAR');
INSERT INTO `uds_hub_master_state` VALUES ('31', '1', 'CHANDIGARH');
INSERT INTO `uds_hub_master_state` VALUES ('32', '1', 'ANDAMAN  NICOBAR');
INSERT INTO `uds_hub_master_state` VALUES ('33', '1', 'UTTARANCHAL');
INSERT INTO `uds_hub_master_state` VALUES ('34', '1', 'JHARKHAND');
INSERT INTO `uds_hub_master_state` VALUES ('35', '1', 'CHATTISGARH');
INSERT INTO `uds_hub_master_state` VALUES ('36', '1', 'TELANGANA');

-- ----------------------------
-- Table structure for `uds_hub_master_status`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_status`;
CREATE TABLE `uds_hub_master_status` (
  `id` int(11) NOT NULL DEFAULT '0',
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of uds_hub_master_status
-- ----------------------------
INSERT INTO `uds_hub_master_status` VALUES ('-1', 'Deleted');
INSERT INTO `uds_hub_master_status` VALUES ('0', 'Disabled');
INSERT INTO `uds_hub_master_status` VALUES ('1', 'Active');

-- ----------------------------
-- Table structure for `uds_hub_master_units`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_units`;
CREATE TABLE `uds_hub_master_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(255) DEFAULT NULL,
  `incrementable` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of uds_hub_master_units
-- ----------------------------
INSERT INTO `uds_hub_master_units` VALUES ('1', 'BHK', '0', '1');
INSERT INTO `uds_hub_master_units` VALUES ('2', 'NOS', '1', '1');

-- ----------------------------
-- Table structure for `uds_hub_master_users`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_users`;
CREATE TABLE `uds_hub_master_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `user_role` bigint(20) DEFAULT NULL,
  `salt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uds_hub_master_users
-- ----------------------------
INSERT INTO `uds_hub_master_users` VALUES ('8', 'nivas', 'bb1e29ef31b659e4c66e71ec30854d1e6edf6e87bf655f5538a0372f50b21fedaffc2d36043c79f1511fd34c00229a11328362e426be90f6bc65e9ccec2b3718460ae6e96e28139cd5c5d8bbf7cb827d4760a83abf86a8a8273a5b4b1f391d3102dd330846fd66af28e4414ae4e8d6bba34d26b21fe183f9cde594fc9a', 'test1@tes.test', '2016-04-06 20:47:01', '1', '1', 'feb40e1cbe5ac1bcdfb896d4b691566cd66ba6790b5b865bd66a6a0694d468f4ed5a11f6c058ac6b53b3320f7ff7c48485e6f00aaa95a1f8d87deba424426c69a58c56598061547b062b11f9507b3953115c551a3fdb877dfd5a1ee76ba675d066979b98236a090a56d44fdc821a8c42af52481c03e10291549a639602');
INSERT INTO `uds_hub_master_users` VALUES ('25', 'justen', '816b30404153e8cc6191571f814586eb257cdb1fc363149a4fc01156d38cb8189d84417d2d27a307506932f45aebd012365e6ce1e6ed45434293256b92551f1e867493da158dbb9c358316b740a7f2d2a59f597c7fc03aedd2ccf416c422a6164f3cbf678aa2b99f541222a8210d9ff6222ca8b82318971b698f48ea4a', 'justen@Ji.com', '2016-07-28 14:03:20', '1', '3', '94d217521dd822aad1d2e909d2e57b9c57262709f917170e78fa32f4e063fd4158a72caae110076f316158d2f92bce23af981fc3072dc0f91c78cce7e77cdfe748d026549a65891b89121dff32a8b238ff09c48a3ead82de009f51a7bd92ed35b77f9f06e4f37fa1ec05f1a912c8008b723e21c3123db7c558e319d745');
INSERT INTO `uds_hub_master_users` VALUES ('26', 'justen3', 'e47fa417486a234d1c71920fbfe19535fefc927c471c0b078dfa6b2f959c26e184be4fd37ed38fa858c542ca4836896368d8df80d42437c24ffab10cb3c91d7f40d03c0999c6f564b41b7366c22070fc435668155723bb4fe62e4c6c3adaa8cb6f8da012ecdaf00ce5e70fdd18e64052910a2f4b7ecea4d831f7b9b26d', 'justen3@gmail.com', '2016-07-28 14:51:41', '1', '4', '26cfeee2cd3ae26f242e3fcd1e1acbf2fc30e336fbe8a02a0fbfeaed15bfd3685957e101f22c04f232deb0df0ebf19bcfa6beb5f889b6579a4f7fc69dd5eff89d1c030773bf52f93ab6387aed4477e8fbf75b6ea8d65e38aec2010642dc4e4f5b42107267d933ec3d094a95006c8252157df6e5633bf2193cb1e146f6a');
INSERT INTO `uds_hub_master_users` VALUES ('28', 'UDSCNY0000000091', 'bc46a784e22c34c99b5f8522f248e01b988bdd435184e812daaeef31883ca6dcf0e27197b88829b1ff4bfe8dfc5e277d955822bf9e22baf0da531505d339ec05bbe5cc86fc38c247bd50d7dbd651d415e5bfea60cee4f0d3d0eb132e9972065749901d9088d5f0a93a62988f76c8ada4ce92df9bb3e965c79b047354fc', 'cvbcv@ef.uj', '2016-08-01 17:45:47', '1', '3', 'c184e1624afd076a6a600d76e59027dba6bc7c9342431727205f6e636957070b3ecb8472e03845c3975a862eaa2c6847660fce09a7a538bb93a85afd104aa45aed16b603d24e6e14e930d2400aa22989a69c09181279689ee7d2dfedea226e12e1ac249edfaef33dcdf7b7ba001cb0072f1427ed41feef72907c2865a0');
INSERT INTO `uds_hub_master_users` VALUES ('29', 'UDSCNY0000000095', '0dafc09c45cf737a319bf9da1449c62b31425f9bc04fc78a9429db3cff1ca7484dba68c92e0a5066c339c064dc60b63f59f62b89bbeab156ce3c2336ba7a1f918257c3a02eb830a3cc4122bd03dc24d830a46d3bebd304c5a6e53e1a85392a4dbed0a04cd45d117300113cc1d22a2be42fc274d7925d3733f1c5d40021', 'dfgdfg@sdf.sdf', '2016-08-01 18:07:00', '1', '3', '30a70007a8ebbf70cedf6607690108032cc3f7e50dcc07a0d2e7683f8f8d58084847e69ffa8085d10327cc9d8de9087c074229fbffc6cea7c5f3b1db439c456da93fe8c51893339dad6e69ab9042f22a81f132e9d9e3d508ece94df866f1b07e2bb5cffd37762e7eb3617c666d532d7ea751c5387cc36779fad93d0512');
INSERT INTO `uds_hub_master_users` VALUES ('30', 'UDSCNY0000000097', 'fab25f72605bf34f6a607e29c97062d593d92186bbe3b40ee0eb0468bc12cf535e300868780d759aadc794097c33a181aed412d3b677427717f56c6c27d4abd74d0eb4f7a557648870892dd9503d8e118ca1427346e8d7104a45456d9d0e91bcd24e45dd6ebb2ed509e6cec2bc748fa4c5544140b8b160769ae0279fbe', 'ggf@efre.lj', '2016-08-01 18:09:07', '1', '3', '7f23dd7769aa8a12d8a3dd33c12f82fdf1f41672bf474cae351d82a27dbfbaf6d81754554d6819e869ca6038b361c83fa9abca3bc4b00991b42410d66cf048ee8161196e2b37bdee66954ceb858547fc3a548711344517d691430955cde205f33841abae780d20a9e142c0fcf57e81e7ca2e49232abd83e294ab93a461');
INSERT INTO `uds_hub_master_users` VALUES ('31', 'UDSCNY0000000100', 'c5ac2d9f21d5f8601e36b6df45c049cddc0467be91dfeeb4fc1f008a9f573917977eff2bc091c84b7f5634fc4077d4ac672f42e1536598ef840af2a1c33dbf92f2d8974fafe8ff0eba8fe3f378a3826d62cd9e8615dfeec680e452b8e40637538085788e280678f4af14cd557827a7c39f03e0f906f94136b8b58edc77', 'sdfsd@rtrhf.ujhgf', '2016-08-01 18:12:57', '1', '3', '717391bbf17536a0b887b88df382cd492b9030b9ad63130e7c4bcd2a1b85924bb7a3e9afdad0e2e828b6debdc9bf9cbe8f8cb41a348203cf303708d5fe01dc34a524729b2497a785aae605bb1a5e832c81f453c4e4a0252c9e49618972af26f5cf552ef6b8f19e72b52128e381b360c6d5571f8f5bddbce982af0b89c3');

-- ----------------------------
-- Table structure for `uds_hub_master_users_roles`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_master_users_roles`;
CREATE TABLE `uds_hub_master_users_roles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_code` varchar(45) DEFAULT NULL,
  `role_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of uds_hub_master_users_roles
-- ----------------------------
INSERT INTO `uds_hub_master_users_roles` VALUES ('1', 'SA', 'Super Admin');
INSERT INTO `uds_hub_master_users_roles` VALUES ('2', 'EMP', 'Employee');
INSERT INTO `uds_hub_master_users_roles` VALUES ('3', 'CA', 'Company Admin');
INSERT INTO `uds_hub_master_users_roles` VALUES ('4', 'HA', 'HUB Admin');

-- ----------------------------
-- Table structure for `uds_hub_transaction_service_prices_history`
-- ----------------------------
DROP TABLE IF EXISTS `uds_hub_transaction_service_prices_history`;
CREATE TABLE `uds_hub_transaction_service_prices_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_id` bigint(20) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `price_date` datetime DEFAULT NULL,
  `company_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of uds_hub_transaction_service_prices_history
-- ----------------------------
