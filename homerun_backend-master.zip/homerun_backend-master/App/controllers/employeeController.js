var validator = require('validator'); 
var db_employee = require('../tables/db_controller/employee.js');
var config = require('../config/generalConfig.js');
var decodedToken = require('../libs/decodedToken.js');
var moment = require('moment');

var EmployeeController = {
	
	_doSave:function(callback,Fields){
		
		db_employee.save(callback,Fields);
		
	},
	
	_doUpdate:function(callback,Fields,id){
		
		db_employee.update(callback,Fields,id);
		
	},
	
	save:function(callback,Fields){
			
			var SaveCallBack = function(err){
				
				if(!err){
					
					db_employee._doSave(callback,Fields);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("NEW",Fields,SaveCallBack);
		
	},

	update:function(callback,Fields,id){
			
			var SaveCallBack = function(err){
				
				if(!err){
				
					db_employee._doSave(callback,Fields,id);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("UPDATE",Fields,SaveCallBack);
		
	},
	
	updatePlain:function(callback,Fields,id){
		
			db_employee.update(callback,Fields,id);
		
	},
	
	updateEmployeeCode:function(callback,id){
		
			db_employee.updateEmployeeCode(callback,id,config.EmployeeCodePrefix);
		
	},
	
	enable:function(callback,id){
		
			EmployeeController.setStatus(callback,1,id);
			
	},
	
	disable:function(callback,id){
		
			EmployeeController.setStatus(callback,0,id); 
			
	},
	
	delete:function(callback,id){
		
			EmployeeController.setStatus(callback,-1,id); 
			
	},
	
	setStatus:function(callback,status,id){
		  
		db_employee.setStatus(callback,status,id);
			 
	},
	  
	validation:function(Opt,fields,SaveCallback){
		
		switch(Opt){
			
			case "NEW":
			case "UPDATE":
			
					if(!fields.employee_first_name || fields.employee_first_name == "undefined" || !validator.isAlpha(fields.employee_first_name) ){
						
						SaveCallback({"status":"error","msg":"Employee First name Is Invalid"});
						
					}
					if(!fields.employee_last_name || fields.employee_last_name == "undefined" || !validator.isAlpha(fields.employee_last_name) ){
						
						SaveCallback({"status":"error","msg":"Employee Last name Is Invalid"});
						
					}
					else if(!fields.employee_code || fields.employee_code == "undefined" ){
						
						SaveCallback({"status":"error","msg":"Employee Code Is Invalid"});
						
					} 
					else if(!fields.gender || fields.gender == "undefined" ){
						
						SaveCallback({"status":"error","msg":"Gender Is Invalid"});
						
					}  
					else if(!moment(fields.date_of_birth,'DD-MM-YYYY').isValid()){

						SaveCallback({"status":"error","msg":"Date of Birth Date is Invalid"});
						
					}
					else if(!moment(fields.date_of_join,'DD-MM-YYYY').isValid()){
						
						SaveCallback({"status":"error","msg":"Date of Join Date is Invalid"});
						
					} 
					else{
						
						SaveCallback(false);
						
					}
					
				break;
			
		}
		
		
	}
	
}

module.exports = EmployeeController;