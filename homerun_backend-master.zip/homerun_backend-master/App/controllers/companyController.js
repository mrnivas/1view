var db_company = require('../tables/db_controller/company.js');
var config = require('../config/generalConfig.js');


var CompanyController = {
	 
	_doSave:function(callback,Fields){
		
		db_company.save(callback,Fields);
		
	}, 
	
	_doUpdate:function(callback,Fields,id){
		
		db_company.update(callback,Fields,id);
		
	}, 
	save:function(callback,Fields){
			
			
			var SaveCallBack = function(err){
				
				if(!err){
					
					CompanyController._doSave(callback,Fields);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("NEW",Fields,SaveCallBack);
		
	},

	update:function(callback,Fields,id){
			
			var SaveCallBack = function(err){
				
				if(!err){
				
					CompanyController._doUpdate(callback,Fields,id);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("UPDATE",Fields,SaveCallBack);
		
	},
	
	isValidHub:function(callback,company_id,hub_id){

			db_company.isValidHub(callback,company_id,hub_id);

	},

	updateCompanyCode:function(callback,CompanyId){
		
			db_company.updateCompanyCode(callback,CompanyId,config.CompanyCodePrefix);
		
	},

	updateHubCode:function(callback,HubId){
		
			db_company.updateCompanyCode(callback,HubId,config.HUBCodePrefix);
		
	},
	
	enable:function(callback,CompanyId){
		
			db_company.setStatus(callback,1,CompanyId);
			
	},
	
	disable:function(callback,CompanyId){
		
			db_company.setStatus(callback,0,CompanyId); 
			
	},
	
	delete:function(callback,CompanyId){
		
			db_company.setStatus(callback,-1,CompanyId); 
			
	},
	
	select:function (){
		 
	
	},
	
	validation:function(Opt,fields,SaveCallback){
		
		switch(Opt){
			
			case "NEW":
			case "UPDATE":
			
					if(fields.company_hub_name == ""){
						
						SaveCallback({"status":"error","msg":"Company name Is Empty"});
						
					}
					else{
						
						SaveCallback(false);
						
					}
					
				break;
			
		}
		
		
	}
	
}

module.exports = CompanyController;