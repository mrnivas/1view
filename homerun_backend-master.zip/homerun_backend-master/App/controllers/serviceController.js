var db_service = require('../tables/db_controller/services.js');
var config = require('../config/generalConfig.js');
var validator = require('validator'); 

var ServiceController = {
	
	_doSave:function(callback,Fields){
		
		db_service.save(callback,Fields);
		
	}, 
	
	_doUpdate:function(callback,Fields,id){
		
		db_service.update(callback,Fields,id);
		
	}, 

	_doSaveServiceUnits:function(callback,Fields){
		
		db_service.saveServiceUnits(callback,Fields);
		
	}, 
	
	_doUpdateServiceUnits:function(callback,Fields,id){
		
		db_service.updateServiceUnits(callback,Fields,id);
		
	}, 
	
	_doSaveServicePrice:function(callback,Fields){
		
		db_service.saveServicePrice(callback,Fields);
		
	},

	_doUpdateServicePrice:function(callback,Fields,id){
		
		db_service.updateServicePrice(callback,Fields,id);
		
	},
	

	save:function(callback,Fields){
			
			
			var SaveCallBack = function(err){
				
				if(!err){
					
					ServiceController._doSave(callback,Fields);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("NEW",Fields,SaveCallBack);
		
	},

	update:function(callback,Fields,id){
			
			var SaveCallBack = function(err){
				
				if(!err){
				
					ServiceController._doUpdate(callback,Fields,id);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("UPDATE",Fields,SaveCallBack);
		
	},

	createServiceUnit:function(callback,Fields){
			 			
			var SaveCallBack = function(err){
				
				if(!err){
					
					ServiceController._doSaveServiceUnits(callback,Fields);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("NEW_SERVICE_UNIT",Fields,SaveCallBack);
		
	},

	createServicePrice : function(callback,Fields){

			var SaveCallBack = function(err){
				
				if(!err){
					
					ServiceController._doSaveServicePrice(callback,Fields);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("NEW_SERVICE_UNIT_PRICE",Fields,SaveCallBack);

	},

	updateServicePrice : function(callback,Fields,id){

			var SaveCallBack = function(err){
				
				if(!err){
					
					ServiceController._doUpdateServicePrice(callback,Fields,id);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("NEW_SERVICE_UNIT_PRICE",Fields,SaveCallBack);

	},
 
	updateServiceUnit:function(callback,Fields,id){
			
			var SaveCallBack = function(err){
				
				if(!err){
				
					ServiceController._doUpdateServiceUnits(callback,Fields,id);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("NEW_SERVICE_UNIT",Fields,SaveCallBack);
		
	},
	
	unblock:function(callback,Id){
		
			db_service.setStatus(callback,1,Id);
			
	},
	
	block:function(callback,Id){
		
			db_service.setStatus(callback,0,Id); 
			
	},
	
	delete:function(callback,Id){
		
			db_service.setStatus(callback,-1,Id); 
			
	},

	deleteServicePrice:function(callback,Id){
		
			db_service.setServicePriceStatus(callback,-1,Id); 
			
	}, 
	
	addCompanyService:function(callback,data){
		
		var SaveCallback = function(res){
			
			if(!res){
				
				db_service.addCompanyService(callback,data);
				
			}
			else{
				
				callback(res);
				
			}
			
		}
		
		this.validation("ADD_SERVICE",data,SaveCallback);
	
	},
	
	removeCompanyService:function(callback,data){
		
		var SaveCallback = function(res){
			
			if(!res){
				
				db_service.removeCompanyService(callback,[data.company_id,data.service_id]);
				
			}
			else{
				
				callback(res);
				
			}
			
		}
		
		this.validation("ADD_SERVICE",data,SaveCallback);
	
	},
	
	validation:function(Opt,fields,SaveCallback){
		
		switch(Opt){
			
			case "NEW":
			case "UPDATE":
			
					if(!validator.isAlpha( fields.service_name) ){
						
						SaveCallback({"status":"error","msg":"Service Name Is Invalid"});
						
					}
					else{
						
						SaveCallback(false);
						
					}
					
			break;

			case "NEW_SERVICE_UNIT":

 				   if(fields.unit_id == "0" ){
						
						SaveCallback({"status":"error","msg":"Unit Is Mandatory"});
						
					}
					if(fields.qty_increment == "-1" ){
						
						SaveCallback({"status":"error","msg":"Quantity Increment is Mandatory"});
						
					}
					else{
						
						SaveCallback(false);
						
					}

			break;

			case "NEW_SERVICE_UNIT_PRICE":

					if(fields.service_id == "0"){

						SaveCallback({"status":"error","msg":"Service Is Mandatory"});

					}

					if(!validator.isNumeric( fields.service_id)){

						SaveCallback({"status":"error","msg":"Service Is Invalid"});

					}
					
					else if(fields.unit_id == "0"){

						SaveCallback({"status":"error","msg":"Unit Is Mandatory"});

					}

					else if(!validator.isNumeric( fields.unit_id)){

						SaveCallback({"status":"error","msg":"Unit Is Invalid"});

					}

					else if(fields.qty == "0"){

						SaveCallback({"status":"error","msg":"Quantity Is Mandatory"});

					}

					else if(!validator.isNumeric( fields.qty)){

						SaveCallback({"status":"error","msg":"Quantity Is Invalid"});

					}

					else if(!validator.isCurrency( fields.customer_price)){

						SaveCallback({"status":"error","msg":"Customer Price Is Mandatory"});

					}

					else if(!validator.isCurrency( fields.third_party_price)){

						SaveCallback({"status":"error","msg":"Third Party Price Is Mandatory"});


					}else{

						SaveCallback(false);

					}

			break; 
			
			case "ADD_SERVICE":
			
				   if(!fields.company_id) {
						
						SaveCallback({"status":"error","msg":"Company Is Invalid"});
						
					}
					else if(!fields.service_id) {
						
						SaveCallback({"status":"error","msg":"Service Is Invalid"});
						
					}
					else{
						
						SaveCallback(false);
						
					}
			
				break;
			
		}
		
		
	}
}

module.exports = ServiceController;