var db_units = require('../tables/db_controller/units.js');
var config = require('../config/generalConfig.js');
var validator = require('validator'); 

var UnitsController = {
	
	_doSave:function(callback,Fields){
		
		db_units.save(callback,Fields);
		
	}, 
	
	_doUpdate:function(callback,Fields,id){
		
		db_units.update(callback,Fields,id);
		
	}, 
	
	save:function(callback,Fields){
			
			
			var SaveCallBack = function(err){
				
				if(!err){
					
					UnitsController._doSave(callback,Fields);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("NEW",Fields,SaveCallBack);
		
	},

	update:function(callback,Fields,id){
			
			var SaveCallBack = function(err){
				
				if(!err){
				
					UnitsController._doUpdate(callback,Fields,id);
				
				}
				else{
					
					callback(err);
							
				}
			}
			
			this.validation("UPDATE",Fields,SaveCallBack);
		
	},
	
	unblock:function(callback,Id){
		
			db_units.setStatus(callback,1,Id);
			
	},
	
	block:function(callback,Id){
		
			db_units.setStatus(callback,0,Id); 
			
	},
	
	delete:function(callback,Id){
		
			db_units.setStatus(callback,-1,Id); 
			
	}, 
	
	validation:function(Opt,fields,SaveCallback){
		
		switch(Opt){
			
			case "NEW":
			case "UPDATE":
			
					if(!validator.isAlpha( fields.unit_name) ){
						
						SaveCallback({"status":"error","msg":"Unit Name Is Invalid"});
						
					}
					if(fields.status == ""){
						
						SaveCallback({"status":"error","msg":"Status Is Invalid"});
						
					}
					else{
						
						SaveCallback(false);
						
					}
					
				break; 
			
		}
		
		
	}
}

module.exports = UnitsController;