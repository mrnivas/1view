var db_users = require('../tables/db_controller/users.js');
var config = require('../config/generalConfig.js');
var validator = require('validator'); 
var passwordTest = require('owasp-password-strength-test');
var crypto = require("crypto");
var companyController = require('../controllers/companyController.js');
var userModel = require('../models/users.js');
var TokenKeyEnc = require('../libs/tokenEncryptKeys.js');
var endedecode = require('../libs/encodeDecodeTockenPayload.js');
var decodedToken = require('../libs/decodedToken.js');


var UserController = {

	login:function(callback,username,password){
		
		var LoginResult = function(result){
			
			if(result.status == "done"){
				
				db_users.selectOne(function(result){
					
					if(result.status == "done"){
						
						var UserInfo = result.data[0];
						
						dt = {};
								
						dt[TokenKeyEnc.get('userid').encoded()] = endedecode.encode(UserInfo.id);
						dt[TokenKeyEnc.get('username').encoded()] = endedecode.encode(UserInfo.username);
						dt[TokenKeyEnc.get('user_role').encoded()] = endedecode.encode(UserInfo.user_role);
						dt[TokenKeyEnc.get('company_id').encoded()] = endedecode.encode(UserInfo.company_id);
						dt[TokenKeyEnc.get('hub_id').encoded()] = endedecode.encode(UserInfo.hub_id);

						callback( { "status":"done", "data":  dt } );	

					}
					else{
							
						callback(result);
						
					}
					
					
				},userModel.userId);
				
			}
			else{
				
				callback(result);
				
			}
			
		}
		
		UserController.loginValidation(LoginResult,username,password);
		
	},
	loginValidation:function(callback,username,password){
		
		var PasswordMatchCallback = function(res){
				
			if(res.status = "done"){
				
				if(res.data.length > 0){
						
					if( userModel.PassWordHash == res.data[0].val ){
							  
						callback({"status":"done"});
						 
					}
					else{
						
						callback({"status":"error","msg":"Invalid Password"});
						
					}
					
				}
				else{
					
					callback({"status":"error","msg":"Invalid Request"});
					
				}
				
			}
			else{
				
				callback(res);
				
			}
			
		}
		
		var EncryptedPasswordBySaltCallback = function(res){
			
			
			userModel.PassWordHash = res.hash;
			userModel.callback = PasswordMatchCallback;
			userModel.getPassword();
			
		}
		
		var PasswordSaltCallBack = function(res){
			
			if(res.status = "done"){
				
				if(res.data.length > 0){
						
					UserController.EncryptedPasswordBySalt(EncryptedPasswordBySaltCallback,password,res.data[0].val );
					
				}
				else{
					
					callback({"status":"error","msg":"Invalid Request"});
					
				}
				
			}
			else{
				
				callback(res);
				
			}
			
		}
		
		
		
		var StartPasswordUpdateValidation = function(){
			
			userModel.callback = PasswordSaltCallBack;
			userModel.getPasswordSalt();
									
		}
		
		var UserNameChecks = function(result){
			
			if(result.status == "done"){
				
				if(result.data.length > 0){
					
					userModel.userId = result.data[0].id;
					StartPasswordUpdateValidation();
					
					
				}
				else{
					
					callback({"status":"error","msg":"Invalid Username"});
					
				}
				
			}
			else{
				
				callback({"status":"error","msg":"Connection Issue"});
				
			}
			
		}
		
		if(username.trim() == ""){
			
			callback({"status":"error","msg":"Username is Empty"});
			
		}
		else if(password == ""){
			
			callback({"status":"error","msg":"Password is Empty"});
			
		}
		else{
			
			db_users.select(UserNameChecks,[username]," username = ? ");
			
		}
			
	},
	
	EncryptedPasswordBySalt:function(callback,password,salt){
		
			crypto.pbkdf2(password, salt, 1000, 125,    function (err, hash) {
				  
				if (err) { throw err; }
				
				 callback( { salt:salt, hash:new Buffer(hash).toString('hex') } ) ;
				  
			});
			
	},
	
	PasswordEncrypter:function(callback,password){
		
		var encp = this.EncryptedPasswordBySalt;
		
		crypto.randomBytes(125, function (err, salt) {
			
			if (err) { throw err; }
			
			salt = new Buffer(salt).toString('hex');
			
			encp(callback,password,salt);
			  
		});
		
	},
	userRoles:function(callback){
 
		db_users.userRoles(callback);
		
	},
	save:function(callback,Fields){
			
			var CompanyId = Fields.company_id;
			var HubId = Fields.hub_id;

			
			var SaveCompanyCallback = function(result){
				
				if(result.status == "done"){
						
						if(CompanyId){
							
							db_users.saveCompanyUser(callback, {"user_id": result.id,"company_id":CompanyId,"hub_id":HubId},result.id  );
								
						}
						else{
							
							callback(result);
							
						}
					
				}
				else{
					
					callback(result);
					
				}
				
				
			}
			
			var SaveCallBack = function(err){
				
				if(!err){
					


					delete Fields.company_id; 
					delete Fields.hub_id;

					db_users.save(SaveCompanyCallback,Fields);
					
				}
				else{
					
					callback(err);
					
				}
				
			}
			
			this.validation("NEW",Fields,SaveCallBack);
		
	},

	update:function(callback,Fields,id){
		
			Fields.id = id;
			var CompanyId = Fields.company_id;
			var HubId = Fields.hub_id;

			
			var SaveCompanyCallback = function(result){
				
				if(result.status == "done"){
						
						if(CompanyId){
				
								db_users.saveCompanyUser(callback,{"user_id": id,"company_id":CompanyId,"hub_id":HubId},id );
								
						}
						else{
							
							callback(result);
							
						}
					
				}
				else{
					
					callback(result);
					
				}
				
				
			}
			
			
			var SaveCallBack = function(err){
				
				if(!err){
					
					delete Fields.company_id; 
					delete Fields.hub_id;

					db_users.update(SaveCompanyCallback,Fields,id);
					
				}
				else{
					
					callback(err);
					
				}
				
			}
			
			this.validation("UPDATE",Fields,SaveCallBack);
		
	},
	  
	savePassword:function(callback,Fields,id){
		
			Fields.id = id;
			 
			var SaveCallBack = function(err){
				
				if(!err){
					
					db_users.update(callback,Fields,id);
					
				}
				else{
					
					callback(err);
					
				}
				
			}
			
			this.validation("SAVE_PASSWORD",Fields,SaveCallBack);
		
	},
	    
	block:function(callback,UserId){
		
		UserController.setStatus("0",callback,UserId);
		
	},
	unblock:function(callback,UserId){
		
		UserController.setStatus("1",callback,UserId);
		
	},
	delete:function(callback,UserId){
			
		UserController.setStatus("-1",callback,UserId);
			
	},
	
	setStatus:function(status,callback,UserId){
		
		db_users.setStatus(status,callback,UserId);
			
	},
	
	selectAll:function (callback){
		
		db_users.selectRaw(callback);
			
	
	} ,
	
	selectAll_filtered:function (callback){
		
		db_users.selectWithoutDeleted(callback);
			
	
	} ,
	
	userGrid:function (callback,company_id,role){

		if(role != "0"){ 
				
				if(!Number(role)  ) {role = "-2";}
		
		}

		db_users.userGrid(callback,company_id,role);
	
	} ,
	
	selectOne:function (callback,id){
		
		db_users.selectOne(callback,id);
			
	
	} ,

	CheckDuplicateUsernameAndEmail:function(callback,fields ){
		
		
			var existsCallBack = function(res,field){
										
					if(res.status == "done"){
						
						if(res.data[0].rows == 0){
							
							if(field!='email'){
								
								if(fields.email){
										
									db_users.selectExisting( existsCallBack,{"email":fields.email} );
										
								}
								else{
									
									callback(false);

								}
								
							}
							else{
								
								callback(false);
								
							}
							
						}
						else{
						
							callback({"status":"error","msg":field+" already Exists"});											
							
						}
						
					}
					else{
						
						callback(res);
						
					}
										
			}
									
			db_users.selectExisting( existsCallBack,{"username":fields.username} );
									
	}, 
	validation:function(Opt,fields,SaveCallback){
		
			var save = SaveCallback;
		
			var DuplicateChecker = UserController.CheckDuplicateUsernameAndEmail ;
						
			var EncryptedPasswordBySalt = UserController.EncryptedPasswordBySalt;
			 
			var UpdateEmailCallback = function(res){
				
				if(res.status = "done"){
					
					if(res.data.length > 0){
							
						if( fields.email == res.data[0].val ){
								
							save(false);	
							
						}
						else{
							
							db_users.selectExisting(function(res,fld){
									
								if(res.status = "done"){
					
									if(res.data[0].rows == 0){
						
										save(false);	
								
									}
									else{
										
										save({"status":"error","msg":"Email Already Exists"});
										
									}
									
								}
								else{
									
									save(res);
									
								}
								
							},{"email":fields.email});
							
						}
						
					}
					else{
						
						save({"status":"error","msg":"Invalid Request"});
						
					}
					
				}
				else{
					
					save(res);
					
				}
				
			}
			
			
			var UpdateUsernameCallback = function(res){
				
				if(res.status = "done"){
					
					if(res.data.length > 0){
						
						if( fields.username == res.data[0].val ){
								
							userModel.callback = UpdateEmailCallback;
							userModel.getEmail();	
							
						}
						else{
							
							db_users.selectExisting(function(res,fld){
									
								if(res.status = "done"){
					
									if(res.data[0].rows == 0){
						
										userModel.callback = UpdateEmailCallback;
										userModel.getEmail();
								
									}
									else{
										
										save({"status":"error","msg":"Username Already Exists"});
										
									}
									
								}
								else{
									
									save(res);
									
								}
								
							},{"username":fields.username});
							
						}
						
					}
					else{
						
						save({"status":"error","msg":"Invalid Request"});
						
					}
					
				}
				else{
					
					save(res);
					
				}
				
			}
			
			var UsernameEmailCheckingWhenUpdate = function(){
				
				userModel.callback = UpdateUsernameCallback;
				userModel.getUserName();
				
			}
						
			var AfterEncryptedPassword = function(res){
					
					fields.password = res.hash;
					fields.salt = res.salt;
					
					switch(Opt){
						
						case "UPDATE":
						
							UsernameEmailCheckingWhenUpdate();
						
						break;

						case "SAVE_PASSWORD":
						
							save(false);
						
						break;

						default:
						
							DuplicateChecker(save,fields);
						
						break;						
							
							
					}
					
			}
			
			var PasswordMatchCallback = function(res){
				
				if(res.status = "done"){
					
					if(res.data.length > 0){
							
						if( userModel.PassWordHash == res.data[0].val ){
								  
							UserController.PasswordEncrypter( AfterEncryptedPassword, fields.password);
							 
						}
						else{
							
							save({"status":"error","msg":"Old Password Not matched"});
							
						}
						
					}
					else{
						
						save({"status":"error","msg":"Invalid Request"});
						
					}
					
				}
				else{
					
					save(res);
					
				}
				
			}
			
			var EncryptedPasswordBySaltCallback = function(res){
				
				
				userModel.PassWordHash = res.hash;
				userModel.callback = PasswordMatchCallback;
				userModel.getPassword();
				
			}
			
			var PasswordSaltCallBack = function(res){
				
				if(res.status = "done"){
					
					if(res.data.length > 0){
							
						EncryptedPasswordBySalt(EncryptedPasswordBySaltCallback,fields.old_password,res.data[0].val );
						
					}
					else{
						
						save({"status":"error","msg":"Invalid Request"});
						
					}
					
				}
				else{
					
					save(res);
					
				}
				
			}
			
			var PasswordRulesPassed = function(pwd,returnError){
				
				var PasswordResult = passwordTest.test(fields.password);
				
				if(PasswordResult.errors.length != 0){
					
					returnError({"status":"error","msg": PasswordResult.errors });
					return false;
					
				}
				else{
					
					return true;
					
				}
				
			}
		
		var StartPasswordUpdateValidation = function(){
			
			userModel.callback = PasswordSaltCallBack;
			userModel.getPasswordSalt();
									
		}
		
		switch(Opt){
			
			case "NEW":
			case "UPDATE":
			
					if(!validator.isAlphanumeric(fields.username) ){
						
						SaveCallback({"status":"error","msg":"Username is Invalid"});
						return;
						
					}
					else if(!validator.isEmail(fields.email)){
						
						SaveCallback({"status":"error","msg":"Email is Invalid"});
						return;
						
					} 
					else{
						
						save = SaveCallback;
						 
						if( Opt == "UPDATE" || PasswordRulesPassed(fields.password,save) ) {
							 
							if( fields.password && fields.password != fields.confirm_password )
							{

								SaveCallback({"status":"error","msg": "Password Not matched" });
								return;
							}
							else{

								delete fields.confirm_password;

							} 
							
							if(!validator.isNumeric(String(fields.user_role))){
						
								SaveCallback({"status":"error","msg":"User Role is Required"});
								return;
							}


							var HubChecking = false;

							if( fields.user_role != 1 ){

							  
								if(!validator.isNumeric(String(fields.company_id))){

									SaveCallback({"status":"error","msg":"Company is Invalid"});
									return;
								}

								if(fields.company_id == "0"){

									SaveCallback({"status":"error","msg":"Company is Required"});
									return;
								}

								if(fields.user_role == 2 || fields.user_role == 4){

									if(fields.hub_id){	

										if(!validator.isNumeric(fields.hub_id)){

											SaveCallback({"status":"error","msg":"Hub is Invalid"});
											return;
										}

										if(fields.hub_id == "0"){

											SaveCallback({"status":"error","msg":"Hub is Required"});
											return;
										}
									
										HubChecking = true;


									}


								}

							 
							}


							if(	!validator.isNumeric(String(fields.status))  ){
						
								SaveCallback({"status":"error","msg":"User Status is Required"});
								return;
								
							}

							var HubChecker = function(res,opt){

										if(res){

											if(Opt == "UPDATE" ){

												StartPasswordUpdateValidation(); 
												 
											}
											else{
												 
												 UserController.PasswordEncrypter( AfterEncryptedPassword, fields.password);

											}

											 
										}
										else{

											SaveCallback({"status":"error","msg":"Hub is Invalid."});	

										}

							 }

							if( Opt == "UPDATE"){
								
								userModel.userId = fields.id;
								
								if( typeof fields.password!='undefined'){
									
									if(fields.old_password){
										
										StartPasswordUpdateValidation(); 
										
									}
									else{
										
										SaveCallback({"status":"error","msg":"Old Password Required"});
										
									}
									
									
									
								}
								else{

									if(HubChecking){
	 
										companyController.isValidHub(HubChecker,fields.company_id,fields.hub_id);

									}
									else{

										UsernameEmailCheckingWhenUpdate();
									
									}
									
									
								}
								
								
							}
							else{
								
								if(HubChecking){
 
									companyController.isValidHub(HubChecker,fields.company_id,fields.hub_id);

								}
								else{

									UserController.PasswordEncrypter( AfterEncryptedPassword, fields.password);
								
								}
							}
							
							 
						}
						
						
					}
					
				break;
				
				case "SAVE_PASSWORD":
						
						var save = SaveCallback;
						 
						if( PasswordRulesPassed(fields.password,save) ) {
						
							userModel.userId = fields.id;
							StartPasswordUpdateValidation(); 
							
						}
						
				break;
			
		}
		
		
	}
	
}

module.exports = UserController;

