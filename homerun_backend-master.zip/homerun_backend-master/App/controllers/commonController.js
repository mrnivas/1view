var db_common = require('../tables/db_controller/common.js');
var config = require('../config/generalConfig.js');


var CommonController = {
 	    
	StateList:function(callback,UserId){
		
		db_common.StateList(callback);
		
	}
	
}

module.exports = CommonController;
