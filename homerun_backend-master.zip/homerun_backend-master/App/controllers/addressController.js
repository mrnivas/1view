var validator = require('validator'); 
var db_addresses = require('../tables/db_controller/addresses.js');

var AddressController = { 
	
	_doSave:function(callback,Fields){
		
		db_addresses.save(callback,Fields);
		
	},
	
	_doUpdate:function(callback,Fields,id){
		
		db_addresses.update(callback,Fields,id);
		
	},
	
	save:function(callback,Fields){
			
			var SaveCallBack = function(err){
				
				if(!err){
				
					db_addresses.save(callback,Fields);
					
				}
				else{
					
					callback(err);
					
				}
				
			}
			
			this.validation("NEW",Fields,SaveCallBack);
	},
	
	update:function(callback,Fields,id){
		
			var SaveCallBack = function(err){
			
				if(!err){
				
					db_addresses.update(callback,Fields,id);
				
				}
				else{
					
					callback(err);
					
				}
				
			}
			
			this.validation("UPDATE",Fields,SaveCallBack);
	},
	
	delete:function(){
		
		
	},
	
	select:function(){
		
		
	},
	
	validation:function(Opt,fields,SaveCallback){
		
		switch(Opt){
			
			case "NEW":
			case "UPDATE":
					
					console.log(fields.state);

					if( !validator.isAlphanumeric(fields.contact_person_name)){
						
						SaveCallback({"status":"error","msg":"Contact Person Is Invalid. Special Charecters not Allowed"});
						
					}
					else if(  !validator.isAlpha(fields.city) ){
						
						SaveCallback({"status":"error","msg":"City Is Invalid. Special Charecters not Allowed"});
						
					}
					else if( !validator.isAlpha(fields.state)  ){
						
						SaveCallback({"status":"error","msg":"State Is Invalid. Special Charecters not Allowed"});
						
					}
					else if(!validator.isNumeric(fields.pincode)){
						
						SaveCallback({"status":"error","msg":"Pincode Is Invalid. Special Charecters not Allowed"});
						
					}
					else if(!validator.isEmail(fields.email )){
						
						SaveCallback({"status":"error","msg":"Email Is Invalid. Special Charecters not Allowed"});
						
					}
					else if(fields.contact_person_phone == ""){
						
						SaveCallback({"status":"error","msg":"Contact Person Phone No Is Invalid"});
						
					}
					else{
						
						SaveCallback(false);
						
					}
					
				break;
			
		}
		 
	}
	
}

module.exports = AddressController;