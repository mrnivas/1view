var jwt = require('jwt-simple');
var config = require('../config/generalConfig.js');
var encodedecode = require('../libs/encodeDecodeTockenPayload.js');
var decodeKeys = require('../libs/tokenEncryptKeys.js');
var decodedToken = require('../libs/decodedToken.js');
var roles = require('../libs/role.js');  


module.exports = function(req, res, next) {

  // When performing a cross domain request, you will recieve
  // a preflighted request first. This is to check if our the app
  // is safe. 

  // We skip the token outh for [OPTIONS] requests.
  //if(req.method == 'OPTIONS') next();

  var token = (req.body && req.body.access_token) || (req.query && req.query.access_token) || req.headers['x-access-token']; 

  if (token ) {
	  
    try {
      
	      var decoded = jwt.decode(token, require('../config/secret.js')());
  	  
        if (decoded.exp <= Date.now()) {
          
          res.json({
            "status": "error",
            "message": "Token Expired"
          });
          
          return;
  		
        }
  	    else{
  		    
    			data = decoded.data;
    			 
    			var structure = {};
    			
    			for( var i in data ){
    				
    				structure[ decodeKeys.get(String(i)).decoded() ] = encodedecode.decode( data[i] );
    				
    			}
    			
          // Checking Roles Permissions

    			decodedToken.token = structure;

          var NotAuthorised = false;

          var methods = function(methods){

              for(var i=0;i<methods.length;i++){

                  if(req.method == methods[i]){

                    return true;

                  }

              }

              return false;

          }
 
          var getUrl = function(url){ 
 
            return req.url.indexOf('/api/auth/'+url) > -1 

          }

          // List the middleware conditions for APIs
 
          if(getUrl('employee')){

               if( roles.isSuperAdmin() || roles.isEmployee() ){

                      NotAuthorised = methods(["GET","PUT","DELETE","POST"]);
  
               }

          }

          if(getUrl('companies')){

               if( !roles.isSuperAdmin() ){

                      NotAuthorised = methods(["GET","PUT","DELETE","POST"]);
  
               }

          }

          if(NotAuthorised){
              
              res.json({
                "status": "error",
                "message": "Authorisation Restricted"
              });
          
              return;

          }

        /*  if(roles.isSuperAdmin()){}

          if(roles.isOrganisationAdmin()){}
              
          if(rolse.isHubAdmin()){}
      
          if(roles.isEmployee()){}  */
  			
  	   }

	     next();
      
    } catch (err) {
		
      res.json({
        "status": "error",
        "message": "Oops something went wrong",
        "error": err
      });
	  
    }

  } 
  else {
    
    res.json({
      "status": "error",
      "message": "Invalid Token or Key"
    });
    return;

  }

};