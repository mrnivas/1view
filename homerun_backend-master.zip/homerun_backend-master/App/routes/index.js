var express = require('express');
var router = express.Router();
var auth = require('./auth.js');
var config = require('../config/generalConfig.js');
var companies = require('./companies.js'); 
var users = require('./users.js'); 
var service = require('./services.js');
var units = require('./units.js'); 	
var employee = require('./employee.js'); 
var common = require('./common.js'); 

/*
 * Routes that can be accessed by any one
 */
router.post('/login', auth.login);
var AuthenticatedApi = config.authUrlPrefix;

//console.log(AuthenticatedApi+'/products');

/*
 * Routes that can be accessed only by autheticated users
 */
 
// Compnay Hub Services
router.get(AuthenticatedApi+'/companies', companies.getAll);
router.get(AuthenticatedApi+'/companies/:id', companies.getOne);
router.post(AuthenticatedApi+'/companies/', companies.create);
router.put(AuthenticatedApi+'/companies/:id', companies.update);
router.delete(AuthenticatedApi+'/companies/:id', companies.delete);
router.get(AuthenticatedApi+'/companies/list/company/', companies.getAllForFrontEnd);

// Hub Details
//router.get(AuthenticatedApi+'/hubs/:parentid', companies.getAllHubs);
//router.get(AuthenticatedApi+'/hubs/:id', companies.getOneHub);
router.post(AuthenticatedApi+'/companies/hubs/', companies.createHub);
router.put(AuthenticatedApi+'/companies/hubs/:id', companies.updateHub);
//router.delete(AuthenticatedApi+'/hubs/:id', companies.deleteHub);*/

//Users Service
router.get(AuthenticatedApi+'/users/company/:id/:role', users.getAll);
router.get(AuthenticatedApi+'/users/:id', users.getOne);
router.get(AuthenticatedApi+'/users/user/roles', users.userRoles);
router.post(AuthenticatedApi+'/users/', users.create); 
router.put(AuthenticatedApi+'/users/:id', users.update);
router.put(AuthenticatedApi+'/users/changepassword/:id', users.save_password);
router.put(AuthenticatedApi+'/users/block/:id', users.block); 
router.put(AuthenticatedApi+'/users/unblock/:id', users.unblock); 
router.delete(AuthenticatedApi+'/users/delete/:id', users.delete); 

//Employee Service
router.get(AuthenticatedApi+'/employee', employee.getAll);
router.get(AuthenticatedApi+'/employee/:id', employee.getOne);
router.post(AuthenticatedApi+'/employee/membercode', employee.getOneByOwnMemberId);
router.post(AuthenticatedApi+'/employee/udsmembercode', employee.getOneByMainMemberId);
router.post(AuthenticatedApi+'/employee', employee.create); 
router.put(AuthenticatedApi+'/employee/:id', employee.update); // need to do
router.put(AuthenticatedApi+'/employee/block/:id', employee.block); 
router.put(AuthenticatedApi+'/employee/unblock/:id', employee.unblock); 
router.delete(AuthenticatedApi+'/employee/:id', employee.delete); 

//Services Service
router.get(AuthenticatedApi+'/service', service.getAll);
router.get(AuthenticatedApi+'/service/:id', service.getOne);
router.get(AuthenticatedApi+'/service/types/:id', service.getAllByParent);
router.get(AuthenticatedApi+'/service/single/line/list', service.SingleLineList);
router.post(AuthenticatedApi+'/service', service.create); 
router.put(AuthenticatedApi+'/service/:id', service.update);
router.put(AuthenticatedApi+'/service/block/:id', service.block); 
router.put(AuthenticatedApi+'/service/unblock/:id', service.unblock); 
router.delete(AuthenticatedApi+'/service/delete/:id', service.delete); 

// Service Units 
router.get(AuthenticatedApi+'/services/units', units.getAll);
router.get(AuthenticatedApi+'/services/units/:id', units.getOne);
router.post(AuthenticatedApi+'/services/units', units.create); 
router.put(AuthenticatedApi+'/services/units/:id', units.update);
router.put(AuthenticatedApi+'/services/units/block/:id', units.block); 
router.put(AuthenticatedApi+'/services/units/unblock/:id', units.unblock); 
router.delete(AuthenticatedApi+'/services/units/delete/:id', units.delete);

router.get(AuthenticatedApi+'/services_units', service.ServiceUnitsList);
router.post(AuthenticatedApi+'/services_units', service.SaveServiceUnits); 
router.put(AuthenticatedApi+'/services_units/:id', service.UpdateServiceUnits); 

router.get(AuthenticatedApi+'/services_units_prices', service.getServicePrices); 
router.post(AuthenticatedApi+'/services_units_prices', service.createServicePrice);
router.put(AuthenticatedApi+'/services_units_prices/:id', service.updateServicePrice);
router.delete(AuthenticatedApi+'/services_units_prices/:id', service.deleteServicePrice); 

//Service With Company
router.post(AuthenticatedApi+'/companyservice/addservice', service.addCompanyService);
router.post(AuthenticatedApi+'/companyservice/removeservice', service.removeCompanyService);
router.post(AuthenticatedApi+'/companyservice/list', service.CompanyServiceList);

//Common
router.get('/common/statelist', common.StateList);

module.exports = router;