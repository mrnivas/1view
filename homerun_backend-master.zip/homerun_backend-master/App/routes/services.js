var ServiceModel = require('../models/services.js');
var moment = require('moment');
var multer = require('multer');
var libs = require('../libs/libs.js'); 
var ServiceController = require('../controllers/serviceController.js');
var decodedToken = require('../libs/decodedToken.js');

var Data = {
	
	ServiceData : function(post){
			
			flds = {
				
				id:0,
				service_name:post.service_name,
				parent_id:post.parent_id?post.parent_id:0,
				status:post.status
					
			};
			
			return libs.trimmer(flds);
		
	} ,

	addCompanyServiceData : function(post){
		
		flds = {

				company_id:post.company_id,
				service_id:post.service_id,
				 
		}
		
		return libs.trimmer(flds);
			
	} ,

	ServiceUnitsData : function(post){

		flds = {
		
				service_id:post.service_id,
				unit_id:post.unit_id,
				qty_increment:post.qty_increment,
				id:0

		}

		return libs.trimmer(flds);

	} ,

	ServicePriceData : function(post){

		flds = {
		
				service_id:post.service_id,
				unit_id:post.unit_id,
				customer_price:post.customer_price,
				third_party_price:post.third_party_price,
				qty:post.qty,
				price_date:moment().format('YYYY-MM-DD HH:mm:ss'),
				id:0

		}

		return libs.trimmer(flds);		

	}
 
}

var Services = {
		
  getAll: function(req, res) {
		
		var ListCallBack = function(result){
			
				res.json(result);
			
		};
		
		
		ServiceModel.get(ListCallBack,{ " a.status != ? " : ["-1"]});
		
  },
  getAllByParent: function(req, res) {
		
		var id = req.params.id; 
		
		var ListCallBack = function(result){
			
				res.json(result);
			
		};
		
		
		ServiceModel.get(ListCallBack,{ " a.status != ? AND parent_id = ?" : ["-1",parseInt(id)]});
		
  },
  getOne: function(req, res) {
		
		var id = req.params.id; 
		
		var ListCallBack = function(result){
			
				res.json(result);
			
		};
		 
		ServiceModel.get(ListCallBack,{ " a.status != ? AND a.id = ? " : ["-1",id] });
		 
	
  },
  create: function(req, res) {
	  
    var post = req.body;
	
	var ServiceData = Data.ServiceData(post);
	
	delete ServiceData.id;ServiceData.status=1;
	  
	var WhenServiceSaved = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Service Saved Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
	ServiceController.save(WhenServiceSaved,ServiceData);
	
  },

  update: function(req, res) {
	  
    var post = req.body;
    var id = req.params.id;
	
	var ServiceData = Data.ServiceData(post);
	ServiceData.id = id;
	 
	var WhenServiceSaved = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Service Saved Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}	
	
	ServiceController.update(WhenServiceSaved,ServiceData,id);
    
  },

  delete: function(req, res) {
    var id = req.params.id;
	
	 var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Service Deleted Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
    ServiceController.delete(isDone,id);
	
  },

  deleteServicePrice:function(req, res) {
     
     var id = req.params.id;
	
	 var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Price Deleted Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
    ServiceController.deleteServicePrice(isDone,id);

  },

  block: function(req, res) {
	  
    var id = req.params.id;
	
	var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Service Blocked Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}
		
		
	ServiceController.block(isDone,id);
    
  },
  
  unblock: function(req, res) {
	  
    var id = req.params.id;
	
	var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Service Un-Blocked Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}
	
	
    ServiceController.unblock(isDone,id);
	
  },
 
  addCompanyService:function(req,res){
	  
	   var post = req.body;
	   
	   data = Data.addCompanyServiceData(post);
	  
       if(decodedToken.token.user_role != 1){
		   
			data.company_id = decodedToken.token.company_id;
		   
	   }
	  
	   var isDone = function(result){
		
			if(result.status == "done"){
			
				res.json({"status":"done","msg":"Service Added Successfully"});
			
			}
			else{
				
				res.json(result);
				
			}
		   
	   }
	   
	   ServiceController.addCompanyService(isDone,data);
	   
  },
  
  removeCompanyService:function(req,res){
	  
	  var post = req.body;
	   
	  data = Data.addCompanyServiceData(post);
	  
	   if(decodedToken.token.user_role != 1){
		   
			data.company_id = decodedToken.token.company_id;
		   
	   }
	   
	   var isDone = function(result){
		
			if(result.status == "done"){
			
				res.json({"status":"done","msg":"Service Removed Successfully"});
			
			}
			else{
				
				res.json(result);
				
			}
		   
	   }
	   
	   ServiceController.removeCompanyService(isDone,data);
	  
  },
  
  CompanyServiceList:function(req,res){
	  
	   var post = req.body;
	   
	   var ListCallBack = function(result){
			
				res.json(result);
			
		};
		
	    if(decodedToken.token.user_role != 1){
		   
			company_id = decodedToken.token.company_id;
		   
	    }
		else{
			
			company_id = post.company_id ? post.company_id : 0;
			
		}
		
	    ServiceModel.getService(ListCallBack,{ " a.status != ? AND b.company_id = ? " : ["-1",company_id]});
	   
  },

  SingleLineList:function(req,res){

  		var ListCallBack = function(result){
			
				res.json(result);
			
		};

		ServiceModel.getSingleLineServiceList(ListCallBack);

  },

  SaveServiceUnits:function(req,res){

  		var post = req.body;
	
		console.log(post); 

		var ServiceUnitsData = Data.ServiceUnitsData(post);
		 
		var WhenServiceUnitSaved = function(result){ 
		
			if(result.status == "done"){
				
				res.json({"status":"done","msg":"Service Unit Saved Successfully"});
				
			}
			else{
				
				res.json(result);
				
			}
			
		}
		
		ServiceController.createServiceUnit(WhenServiceUnitSaved,ServiceUnitsData);

  },

  UpdateServiceUnits:function(req,res){

  		var post = req.body;
  		var id = req.params.id;
  	
		var ServiceUnitsData = Data.ServiceUnitsData(post);
		ServiceUnitsData.id = id;

		var WhenServiceUnitSaved = function(result){ 
		
			if(result.status == "done"){
				
				res.json({"status":"done","msg":"Service Unit Saved Successfully"});
				
			}
			else{
				
				res.json(result);
				
			}
			
		}
		
		ServiceController.updateServiceUnit(WhenServiceUnitSaved,ServiceUnitsData,id);

  },  

  ServiceUnitsList : function(req,res){

   		var ListCallBack = function(result){
			
				res.json(result);
			
		};

		ServiceModel.getServiceUnitList(ListCallBack);

  },

  getServicePrices : function(req,res){

		var ListCallBack = function(result){
			
				res.json(result);
			
		};

		ServiceModel.getServicePrices(ListCallBack);

  },

  createServicePrice : function(req,res){

  		var post = req.body; 
  	
		var ServicePriceData = Data.ServicePriceData(post);
		 
		var WhenServicePriceDataSaved = function(result){ 
		
			if(result.status == "done"){
				
				res.json({"status":"done","msg":"Service Price Saved Successfully"});
				
			}
			else{
				
				res.json(result);
				
			}
			
		}
		
		ServiceController.createServicePrice(WhenServicePriceDataSaved,ServicePriceData);
 
  },

  updateServicePrice : function(req,res){

  		var post = req.body; 

  		var id = req.params.id;
  	
		var ServicePriceData = Data.ServicePriceData(post);

		ServicePriceData.id = id;		

		var WhenServicePriceDataSaved = function(result){ 
		
			if(result.status == "done"){
				
				res.json({"status":"done","msg":"Service Price Saved Successfully"});
				
			}
			else{
				
				res.json(result);
				
			}
			
		}
		
		ServiceController.updateServicePrice(WhenServicePriceDataSaved,ServicePriceData,id);
 
  }


	
}

module.exports = Services;