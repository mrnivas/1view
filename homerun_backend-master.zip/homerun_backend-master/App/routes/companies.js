var CompanyModel = require('../models/companies.js');
var moment = require('moment'); 
var libs = require('../libs/libs.js'); 
var AddressController = require('../controllers/addressController.js');
var CompanyController = require('../controllers/companyController.js');
var decodedToken = require('../libs/decodedToken.js');
var userController = require('../controllers/userController.js');

var Data = {
	
	Address  : function(post){
	
		filds =   {
						"address":post.address,
						"contact_person_name":post.contact_person_name,
						"city":post.city,
						"state":post.state,
						"pincode":post.pincode,
						"phone":post.phone,
						"email":post.email,
						"contact_person_phone":post.contact_person_phone,
						"address_type":(post.company_type!=undefined?post.company_type:"COMPANY")
				  };
		
		return libs.trimmer(filds);
		
	},

	Company  : function(post){
	
		filds =   {
						"company_hub_name":post.company_hub_name,
						"created_type":"CREATED",
						"created_at":moment().format('YYYY-MM-DD HH:mm:ss'),
						"parent_id":(post.parent_id!=undefined?post.parent_id:0),
						"is_primary":0,
						"created_by":1,
						"status":(post.status!=undefined?post.status:0),
						"company_type":(post.company_type!=undefined?post.company_type:"COMPANY")
		};

		if(post.address_id){

			filds.address_id = post.address_id;

		}
		
		return libs.trimmer(filds);
					  
	}

	
}
	
var companies = {

  getAll: function(req, res) {
		
		var ListCallBack = function(result){
			
				res.json(result);
			
		};
		
		if(decodedToken.token.user_role == 1){
			
			CompanyModel.get(ListCallBack,{ "a.status <> ? and parent_id = 0" : ["-1"] });
				
		}
		else{
			
			res.json({status:"error",msg:'permssison denied'});

		}
		 
	
  },

  getAllCompanyForFrontEnd: function(req, res) {
		
		var ListCallBack = function(result){
			
				res.json(result);
			
		};



		if(decodedToken.token.user_role == 1){
 
			CompanyModel.get(ListCallBack,{ "a.status > ? " : ["0"] });
				
		}
		else if (decodedToken.token.user_role == 3){
			
			CompanyModel.get(ListCallBack,{ "a.status > ? AND (a.id = ? || a.parent_id = ? )" : ["0" ,decodedToken.token.company_id,decodedToken.token.company_id]});
			
		}
		else{

			CompanyModel.get(ListCallBack,{ "a.status > ? AND (a.id = ? || a.id = ? )" : ["0" ,decodedToken.token.company_id,decodedToken.token.hub_id]});

		}
		 
	
  },

  getAllForFrontEnd: function(req, res) {
		
		var ListCallBack = function(result){
			
				res.json(result);
			
		};



		if(decodedToken.token.user_role == 1){
 
			CompanyModel.get(ListCallBack,{ "status > ? " : ["-1"] });
				
		}
		else if (decodedToken.token.user_role == 3){
			
			CompanyModel.get(ListCallBack,{ "status > ? AND (a.id = ? || a.parent_id = ? )" : [-1,"0" ,decodedToken.token.company_id,decodedToken.token.company_id]});
			
		}
		else{

			CompanyModel.get(ListCallBack,{ "status > ? AND  (a.id = ? || a.id = ? )" : [-1,"0" ,decodedToken.token.company_id,decodedToken.token.hub_id]});

		}
		 
	
  },

   getAllHubForFrontEnd: function(req, res) {

   		var company_id = req.param.id;
   		var hub_id = 0;


   		if(decodedToken.token.user_role !=1 ){

   			company_id = decodedToken.token.company_id;
 			
   			if(decodedToken.token.user_role == 2 || decodedToken.token.user_role == 4){

   				hub_id = decodedToken.token.hub_id;

   			}

   		}
		


		var ListCallBack = function(result){
			
				res.json(result);
			
		};
		
		if(hub_id == 0){

			CompanyModel.get(ListCallBack,{' status > ?':['-1']} );
			 
		}
		else{

			CompanyModel.get(ListCallBack,{ " stauts > ? AND a.parent_id = ? AND a.id =? " : [ -1,decodedToken.token.company_id,decodedToken.token.hub_id]});
			 
		}
	
  },


  getOne: function(req, res) {
		
		var id = req.params.id; 
		
		var ListCallBack = function(result){
			
				res.json(result);
			
		};
		
		if(decodedToken.token.user_role == 1){
			
			CompanyModel.get(ListCallBack,{ " a.status != ? AND a.id = ? " : ["-1",id] });
				
		}
		else{
			
			CompanyModel.get(ListCallBack,{ " a.id = ? AND a.status <> ? AND a.parent_id = ? " :[id,-1,decodedToken.token.company_id] });
			
		}
		
	
  },

  createHub:function(req,res){
 
  	 req.body.company_type = "HUB";

  	 companies.create(req,res);

  },

  updateHub:function(req,res){
 
  	 req.body.company_type = "HUB";

  	 companies.update(req,res);

  },

  create: function(req, res) {
	   
		var post = req.body;
		
		var Address = Data.Address(post);
		
		var CompanyInfo = Data.Company(post);

		var CompanyId;
		
		var CompanyCode;



		if(CompanyInfo.parent_id != 0){

			CompanyInfo.company_type = "HUB";
			Address.address_type = "HUB";
			
		}
		
		if(decodedToken.token.user_role!=1){
			
			CompanyInfo.parent_id = decodedToken.token.company_id;
			CompanyInfo.company_type = "HUB";
			Address.address_type = "HUB";
			
		}

		if(decodedToken.token.user_role==1 && CompanyInfo.company_type == "HUB" && CompanyInfo.parent_id == 0){

			res.json({status:'error','msg':'Choose the Company'});
			return;

		}

		if(CompanyInfo.status == ""){

			res.json({status:'error','msg':'Choose the Status'});
			return;

		}


		
		var AllareCompletedCallback = function(result){

 
			CompanyCode = result.data[0].code;
 

			AddressController._doSave(function(addressResult){

				if(addressResult.status == "done"){

					 
					if(CompanyInfo.company_type != "HUB"){

								CompanyInfo.address_id = addressResult.id;
								CompanyInfo.company_type = "HUB";
								CompanyInfo.parent_id = CompanyId;

								CompanyController._doSave(function(cnyResult){


									if(cnyResult.status == "done"){

										CompanyController.updateHubCode(function(hubSaved){

											if(hubSaved.status == "done"){

												var text = "";
												
											    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

											    for( var i=0; i < 5; i++ ){

											        text += possible.charAt(Math.floor(Math.random() * possible.length));
											    
											    }

												flds = {
								
														username:CompanyCode,
														password:'Uds'+CompanyId+'@'+text,
														confirm_password:'Uds'+CompanyId+'@'+text,
														email:Address.email,
														created_at:moment().format('YYYY-MM-DD HH:mm:ss'),
														status:"1",
														company_id:String(CompanyId),
														hub_id:"0",
														user_role:"3"
														
												};


												userController.save(function(_data){
			 

													if(_data.status == "done"){

														res.json({status:'done','msg':'Company Saved Successfully The Default Hub & User Also Created.'});

													}
													else{

														res.json({status:'done','msg':'Company Saved Successfully The Default Hub Also Created. But User Creation Faild'});

													}

												},flds);
			 

											}
											else{

												res.json(hubSaved);

											}


										},cnyResult.id);

									}	
									else{

										res.json(cnyResult);

									}


								},CompanyInfo);	

					}	
					else{

						res.json({status:'done','msg':'Hub Saved Successfully '});

					}


				}
				else{

					res.json(result);

				
				}	

			},Address);
			
			 	
			
		}
		
		var SavedCompanyCallback = function(result){
			 
			if(result.status == "done"){
				
				CompanyId = result.id;

				if(CompanyInfo.company_type == "HUB"){


						CompanyController.updateHubCode(function(_data){

							if(_data.status == "done"){

									res.json({status:'done','msg':'Hub Saved Successfully '});

							}
							else{

									res.json(_data);

							}
 

						},CompanyId)


				}
				else{

					CompanyController.updateCompanyCode(AllareCompletedCallback,CompanyId);

				}
				
		 
			}
			else{
				
				res.json(result);
				
			}
			
		}
		
		var SavedAddressCallback = function(result){
			
			if(result.status == "done"){
				
				CompanyInfo.address_id = result.id;
				CompanyController._doSave(SavedCompanyCallback,CompanyInfo);
				
			}
			else{
				
				res.json(result);
				
			}
			
		}
		
		CompanyController.validation("NEW",CompanyInfo,function(err){
		
			if(!err){
				
				AddressController.validation("NEW",Address,function(err){
					
					if(!err){
						
						
						AddressController._doSave(SavedAddressCallback,Address);
						
					}
					else{
							
						res.json(err);
						
					}
					
				});
				
			}
			else{
				
				res.json(err);
				
			}
			
		});
			
  },
	
  update: function(req, res) {
	  
		var post = req.body;
		var id = req.params.id; 
		
		var Address = Data.Address(post);
		var CompanyInfo = Data.Company(post);
		
		if(decodedToken.token.user_role!=1){
			
			CompanyInfo.parent_id = decodedToken.token.company_id;
			CompanyInfo.company_type = "HUB";
			Address.address_type = "HUB";
			
		}
		
		var UpdateAddressCallback = function(result){
				
			res.json(result);
				
		}
		
		var UpdateCompanyCallback = function(result){
			
			 if(result.status == "done"){


					AddressController._doUpdate(UpdateAddressCallback,Address,CompanyInfo.address_id);
				 
			 }
			 else{
					
					res.json(result);
					
			 }
			 
		}
		
		
		CompanyController.validation("UPDATE",CompanyInfo,function(err){
		
			if(!err){
				
				AddressController.validation("UPDATE",Address,function(err){
					
					if(!err){
						
						
						CompanyController._doUpdate(UpdateCompanyCallback,CompanyInfo,parseInt(id));
						
					}
					else{
							
						res.json(err);
						
					}
					
				});
				
			}
			else{
				
				res.json(err);
				
			}
			
		});
		
		
  },

  delete: function(req, res) {
	  
		var id = req.params.id; 
		
		var AllareCompletedCallback = function(result){
			
			 res.json(result);
			
		}
		
		CompanyController.delete(AllareCompletedCallback,parseInt(id));
	
  }
  
};

module.exports = companies;