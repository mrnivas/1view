var CompanyModel = require('../models/companies.js');
var moment = require('moment'); 
var libs = require('../libs/libs.js'); 
var UserController = require('../controllers/userController.js');
var decodedToken = require('../libs/decodedToken.js');

var Data = {
	
	UserData : function(post){
			
			flds = {
					
					username:post.username,
					password:post.password,
					email:post.email,
					confirm_password:post.confirm_password,
					created_at:moment().format('YYYY-MM-DD HH:mm:ss'),
					status:post.status,
					company_id:(post.company_id ? String(post.company_id) : 0),
					user_role:post.user_role
					
			};
			
			return libs.trimmer(flds);
		
	},
	ChangePassword : function(post){
		
		return flds = { password:post.password,old_password:post.old_password }	
			
	}
	
}


var users = {

  getAll: function(req, res) {

  	var post = req.params.id;

  	var role_id = req.params.role;
    
	var Lists = function(result){
		
			res.json(result);
			
	}


	UserController.userGrid(Lists,req.params.id,role_id);
 
    
  },

  getOne: function(req, res) {
	  
    var id = req.params.id;
	
	var List = function(result){
		
			res.json(result);
			
	}
	
	UserController.selectOne(List,id);
     
  },
  userRoles : function(req,res){
	
	
	UserController.userRoles(function(result){
		 
			res.json(result);
		
	});
	
  },
  create: function(req, res) {
	  
    var post = req.body;
	
	var UserData = Data.UserData(post);
	
	var WhenUserSaved = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"User Saved Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
	UserController.save(WhenUserSaved,UserData);
	
  },

  update: function(req, res) {
	  
    var post = req.body;
    var id = req.params.id;
	
	var UserData = Data.UserData(post);
	
	if(post.password){
		
		UserData.old_password = post.old_password;
			
	}
	else{
		
		delete UserData.password;
		
	}
	
	
	var WhenUserSaved = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"User Saved Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
	UserController.update(WhenUserSaved,UserData,id);
    
  },
  save_password:function(req,res){
	  
	  var post = req.body;
	  var id = req.params.id;
		
	  var change_password_data = Data.ChangePassword(post);
		
	  var WhenUserSaved = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Password Changed Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
	UserController.savePassword(WhenUserSaved,change_password_data,id);
	  
  },

  delete: function(req, res) {
     var id = req.params.id;
	
	 var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"User Deleted Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
    UserController.delete(isDone,id);
	
  },
  block: function(req, res) {
	  
    var id = req.params.id;
	
	var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"User Blocked Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}
		
		
	UserController.block(isDone,id);
    
  },
  
  unblock: function(req, res) {
	  
    var id = req.params.id;


	
	var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"User Un-Blocked Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}
	
	
    UserController.unblock(isDone,id);
	
  }
  
  
};
 
module.exports = users;
