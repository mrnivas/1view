var jwt = require('jwt-simple');
var UserController = require('../controllers/userController.js');

var auth = {

  login: function(req, res) {

    var username = req.body.username || '';
    var password = req.body.password || '';

    if (username == '' || password == '') {
      res.status(401);
      res.json({
        "status": 401,
        "message": "Invalid credentials"
      });
      return;
    }

    var LoginCallback = function(dbUserObj){
		
		if (dbUserObj.status == "done") { 
		
		  token = genToken(dbUserObj);
		  
		  res.json({"status":"done","token":token});
		  
		}
		else{
			
			res.json(dbUserObj);
			
		}
		
	}
	
	var genToken  = function(user) {
	  
	   var expires = expiresIn(7); // 7 days
	   
	   function merge_options(obj1,obj2){
				var obj3 = {};
				for (var attrname in obj1) { obj3[attrname] = obj1[attrname]; }
				for (var attrname in obj2) { obj3[attrname] = obj2[attrname]; }
				return obj3;
	  }

	  exp = {exp: expires};
	  
	  paynotes = merge_options(exp,user);
	  
	 
	  var token = jwt.encode( paynotes , require('../config/secret')());

	  return  token;
	  
	}

	var expiresIn = function(numDays) {
		
	  var dateObj = new Date();
	  return dateObj.setDate(dateObj.getDate() + numDays);
	  
	}
	
	UserController.login(LoginCallback,username, password);

  } 
  
}


module.exports = auth;
