var UnitsModel = require('../models/units.js');
var moment = require('moment');
var multer = require('multer');
var libs = require('../libs/libs.js'); 
var UnitsController = require('../controllers/unitsController.js');
var decodedToken = require('../libs/decodedToken.js');

var Data = {
	
	UnitsData : function(post){
			
			flds = {
					
					id:0,
					unit_name:post.unit_name, 
					status:post.status
					
			};
			
			return libs.trimmer(flds);
		
	}  
};
 
var Units = {
		
  getAll: function(req, res) {

  		 

		var ListCallBack = function(result){

				res.json(result);
			
		};
		
		
		UnitsModel.get(ListCallBack,{ " a.status != ? " : ["-1"]});
		
  }, 
  getOne: function(req, res) {
		 

		var id = req.params.id; 
		
		var ListCallBack = function(result){
			
				res.json(result);
			
		};
		 
		UnitsModel.get(ListCallBack,{ " a.status != ? AND a.id = ? " : ["-1",id] });
		 
	
  },
  create: function(req, res) {
	  

    var post = req.body;
	
	var UnitsData = Data.UnitsData(post);
	
	delete UnitsData.id; 
	  
	var WhenServiceSaved = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Unit Saved Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
	UnitsController.save(WhenServiceSaved,UnitsData);
	
  },

  update: function(req, res) {
	  
    var post = req.body;
    var id = req.params.id;
	
	var UnitsData = Data.UnitsData(post);
	UnitsData.id = id;
	 
	var WhenUnitsSaved = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Unit Saved Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}	
	
	UnitsController.update(WhenUnitsSaved,UnitsData,id);
    
  },

  delete: function(req, res) {
    var id = req.params.id;
	
	 var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Unit Deleted Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
    UnitsController.delete(isDone,id);
	
  },
  block: function(req, res) {
	  
    var id = req.params.id;
	
	var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Unit Blocked Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}
		
		
	UnitsController.block(isDone,id);
    
  },
  
  unblock: function(req, res) {
	  
    var id = req.params.id;
	
	var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Unit Un-Blocked Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}
	
	
    UnitsController.unblock(isDone,id);
	
  } 
	
}

module.exports = Units;