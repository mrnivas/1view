var EmployeeModel = require('../models/employee.js');
var moment = require('moment'); 
var libs = require('../libs/libs.js'); 
var EmployeeController = require('../controllers/employeeController.js');
var UserController = require('../controllers/userController.js');
var AddressController = require('../controllers/addressController.js');
var decodedToken = require('../libs/decodedToken.js');

var DateReverced = function(dt){

	sp = dt.split('-');

	console.log(sp[2]+'-'+sp[1]+'-'+sp[0]);

	return sp[2]+'-'+sp[1]+'-'+sp[0];

}

var Data = {
	
	Address  : function(post){
	
		filds =   {
						"address":post.address,"contact_person_name":post.employee_first_name,
						"city":post.city,"state":post.state,"pincode":post.pincode,"phone":post.phone,"email":post.email,
						"contact_person_phone":post.phone,"address_type":"PERSON"
				  };
		
		return libs.trimmer(filds);
		
	},
	
	EmployeeData : function(post){
			
			flds = {
					
					employee_first_name:post.employee_first_name,
					employee_last_name:post.employee_last_name,
					employee_code:post.employee_code,
					gender:post.emplayee_gender,
					date_of_birth:post.dob,
					date_of_join:post.doj,   
					created_at:moment().format('YYYY-MM-DD HH:mm:ss'),
					status:post.status
					
			};
			
			return libs.trimmer(flds);  	
		
	},

	ChangePassword : function(post){
		
		return flds = { password:post.password,old_password:post.old_password }	
			
	}
	
}


var Employee = {

  getAll: function(req, res) {
    
	var ModelResult = function(result){
		
		res.json(result);
		
	}
	
	if(decodedToken.token.user_role == 1){
			
			EmployeeModel.get(ModelResult,{" a.status <> ? ":[-1]});
			
	}
	else{
		
			EmployeeModel.get(ModelResult,{" a.status <> ? AND a.employee_company_id = ? ":[-1,decodedToken.token.company_id]});
		
	}
		
    
  },

  getOne: function(req, res) {
    
	var id = req.params.id;
	
	var ModelResult = function(result){
		
		res.json(result);
		
	}
	
	if(decodedToken.token.user_role == 1){
		
		EmployeeModel.get(ModelResult,parseInt(id));
	
	}
	else{
		
			EmployeeModel.get(ModelResult,{" a.id <> ? AND a.employee_company_id = ? ":[id,decodedToken.token.company_id]});
		
	}
	
     
  },

  create: function(req, res) {
	  
    var post = req.body;
	
	var EmployeeData = Data.EmployeeData(post);
	
	var Address = Data.Address(post);
	 				
	EmployeeData.employee_company_id = decodedToken.token.company_id
	 
	var CreatedUserId = 0;
	
	var WhenEmployeeSaved = function(result){ 
	
		if(result.status == "done"){
			
			CreatedUserId = result.id;
			
			var EmployeeModelResult = function(result){
				
				if(result.status == "done"){
					
					if(result.data.length > 0){
						
						var info = result.data[0];
						
						userdata = { 
								
								username:info.uds_employee_code,
								password:("Uds1@"+info.email),
								confirm_password:("Uds1@"+info.email),
								email:info.email,
								created_at:moment().format('YYYY-MM-DD HH:mm:ss'),
								status:1,
								company_id:info.employee_company_id,
								user_role:2
								
						};
						
						UserController.save(function(result){
							
							if(result.status == "done"){
								
								EmployeeController.updatePlain(function(result){
									
									if(result.status == "done"){
										
										res.json({"status":"done","msg":"Employee Created. You can login with UDS member code as username and same for password"});
										
									}
									else{
										
										res.json({"status":"done","msg":"Employee Created. But User info Not Maped"});
										
									}
									
								},{user_id:result.id},CreatedUserId);

							}
							else{
								
								//res.json({"status":"error","msg":"Employee Created But User creation failed. may be the email is duplication"});
								res.json(result);
								
							}
							
						},userdata);
						
					}
					else{
						
						res.json({"status":"error","msg":"Employee Created But User creation failed"});
						//res.json(result);
						
					}
					
				}
				else{
					
					res.json({"status":"error","msg":"Employee Created But User creation failed"});
					//res.json(result);
					
				}
				
			}
			
			EmployeeController.updateEmployeeCode(function(result){
				
				if(result.status == "done"){
					
					// Add On user Table
					EmployeeModel.get(EmployeeModelResult,CreatedUserId);
					
				}
				else{
					
					res.json(result);
					
				}
				
			},CreatedUserId);
			
			
			//res.json({"status":"done","msg":"Employee Saved Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
	var SavedAddressCallback = function(result){
			
			if(result.status == "done"){
				
				EmployeeData.address_id = result.id;

				EmployeeData.date_of_birth = DateReverced(EmployeeData.date_of_birth); 
				
				EmployeeData.date_of_join = DateReverced(EmployeeData.date_of_join);

				EmployeeController._doSave(WhenEmployeeSaved,EmployeeData);
				
			}
			else{
				
				res.json(result);
				
			}
			
	}
	 
	
	EmployeeController.validation("NEW",EmployeeData,function(err){
		
			if(!err){
				
				AddressController.validation("NEW",Address,function(err){
					
					if(!err){
						
						
						AddressController._doSave(SavedAddressCallback,Address);
						
					}
					else{
							
						res.json(err);
						
					}
					
				});
				
			}
			else{
				
				res.json(err);
				
			}
			
	});	
	
	
  },

  update: function(req, res) {
	  
		var post = req.body;
		var Employeeid = req.params.id; 
		
		Employeeid = parseInt(Employeeid);
		
		var EmployeeData = Data.EmployeeData(post);
	
		delete EmployeeData.address_id;
		
		var Address = Data.Address(post);
		
		var SavedAddressCallback = function(result){
			
			if(result.status == "done"){
	
				EmployeeData.date_of_birth = DateReverced(EmployeeData.date_of_birth); 
				
				EmployeeData.date_of_join = DateReverced(EmployeeData.date_of_join);
 
				EmployeeController._doUpdate(function(result){
					
					if(result.status == "done"){
						
						res.json({"status":"done","msg":"Employee Details Updated"});		
						
					}
					else{
						
						res.json(result);
						
					}
					
				},EmployeeData,Employeeid);
				
			}
			else{
				
				res.json(result);
				
			}
			
		}
		
		EmployeeController.validation("UPDATE",EmployeeData,function(err){
				
				if(!err){
					
					AddressController.validation("UPDATE",Address,function(err){
						
						if(!err){
							
								EmployeeModel.get(function(modRes){
									
									if(modRes.status == "done"){
										
										if(modRes.data.length > 0){
											
											EmployeeData.employee_company_id = modRes.data[0].employee_company_id;
						 
											AddressController._doUpdate(SavedAddressCallback,Address,modRes.data[0].address_id);
											
										}
										else{
										
											res.json({"status":"error","msg":"Invalid Request"});										
											
										}
										
									}
									else{
										
										res.json(modRes);
										
									}
									
								},Employeeid);
								
						}
						else{
								
							res.json(err);
							
						}
						
					});
					
				}
				else{
					
					res.json(err);
					
				}
				
		});	
		
  },

  delete: function(req, res) {
	  
    var id = req.params.id;
	
	 var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Employee Deleted Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
		
	}
	
    EmployeeController.delete(isDone,id);
	
  },
  block: function(req, res) {
	  
    var id = req.params.id;
	
	var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Employee Blocked Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}
		
		
	EmployeeController.disable(isDone,id);
    
  },
  
  unblock: function(req, res) {
	  
    var id = req.params.id;
	
	var isDone = function(result){ 
	
		if(result.status == "done"){
			
			res.json({"status":"done","msg":"Employee Un-Blocked Successfully"});
			
		}
		else{
			
			res.json(result);
			
		}
	}
	
	
    EmployeeController.enable(isDone,id);
	
  },
  
  getOneByOwnMemberId : function(req, res) {
	
	var id = req.body.id;
	
	var ModelResult = function(result){
		
		res.json(result);
		
	}
	
	if(decodedToken.token.user_role == 1){
		
		EmployeeModel.get(ModelResult,{" a.emplayee_code = ? AND a.status <> ? ":[id,-1]});
	
	}
	else{
		
		EmployeeModel.get(ModelResult,{" a.emplayee_code = ? AND a.status <> ? AND a.employee_company_id = ? ":[id,-1,decodedToken.token.company_id]});
		
	}
	 
  },
  
  getOneByMainMemberId : function(req, res) { 
  
	var id = req.body.id;
	
	var ModelResult = function(result){
		
		res.json(result);
		
	}
	
	if(decodedToken.token.user_role == 1){
		
		EmployeeModel.get(ModelResult,{" a.uds_employee_code = ? AND a.status <> ? ":[id,-1]});
	
	}
	else{
		
		EmployeeModel.get(ModelResult,{" a.uds_employee_code = ? AND a.status <> ? AND a.employee_company_id = ? ":[id,-1,decodedToken.token.company_id]});
		
	}
	
  }
  
  
};
 
module.exports = Employee;