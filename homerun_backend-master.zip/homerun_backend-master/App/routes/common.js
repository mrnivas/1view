var moment = require('moment'); 
var libs = require('../libs/libs.js'); 
var CommonController = require('../controllers/commonController.js');
var decodedToken = require('../libs/decodedToken.js');

var Data = {
	 
}


var Common = {

  StateList: function(req, res) {
    
	var Lists = function(result){
		
			res.json(result);
			
	}
	
	CommonController.StateList(Lists);
    
  }

};
 
module.exports = Common;
