var config = require('../config/generalConfig.js');
var Prefix = config.TablePrefix;
var Tables = {
	
		UserMaster 	: Prefix+"master_users",
		UserRollMaster : Prefix+"master_users_roles",
		ServiceMaster : Prefix+"master_services",
		CompanyHubMaster : Prefix+"master_company_hub",
		AddressMaster : Prefix+"master_addresses",
		EmployeeMaster : Prefix+"master_company_employees",
		CompanyUserMaster : Prefix+"master_company_hub_users",
		CompanyServiceMaster : Prefix+"master_company_hub_services",
		UnitsMaster : Prefix+"master_units",
		ServiceUnitsMaster : Prefix+"master_service_units",
		StateMaster : Prefix+"master_state",
		Status : Prefix+"master_status",
		ServicePrices : Prefix+"master_service_prices"
		
}

module.exports = Tables;