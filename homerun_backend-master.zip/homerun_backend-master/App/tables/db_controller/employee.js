var db = require('../../config/db.js');
var qeObj = require('../query.js');
var tables = require('../tables.js');

var Employee = {
	
	tables:tables,
	
	save : function(callback,Fields){
		 
		Q = "INSERT INTO "+this.tables.EmployeeMaster+" SET ?"
	
		db.query(Q,Fields,function(err,result){
						
				qe = new qeObj("INSERT",err,result); 
				callback(qe.Exec());
				
		});
	 
				
	},
	
	update : function(callback,Fields,id){
		
		Q = "UPDATE "+this.tables.EmployeeMaster+" SET ? WHERE id = ?";
			
			db.query(Q,[Fields,id],function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
		});
			
	},
	
	updateEmployeeCode : function(callback,id,empPrefix){
		
		Q = "UPDATE "+this.tables.EmployeeMaster+" SET uds_employee_code = CONCAT('"+empPrefix+"',LPAD('"+id+"',10,0)) WHERE id = '"+id+"' ";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
		});
			
	},
	
	setStatus:function(callback,status,CompanyId){
		
			Q = "UPDATE "+this.tables.EmployeeMaster+" SET status = "+status+" WHERE id = '"+CompanyId+"' ";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});
			
	},
	
	select : function(callback,ConditionFields,conditionVals){
		 
			Q  = "SELECT"+
				 " a.id,a.employee_first_name,a.employee_last_name,a.status,a.gender,a.employee_code,a.uds_employee_code,a.address_id,"+
				 " a.created_at,a.employee_company_id,DATE_FORMAT(date_of_birth,'%d-%m-%Y') as dob,DATE_FORMAT(date_of_join,'%d-%m-%Y') as doj, "+
				 " (SELECT st.status FROM "+this.tables.Status+" st WHERE st.id = a.status) as status_text, "+
				 " (SELECT cny.company_hub_name FROM "+this.tables.CompanyHubMaster+" cny where cny.id = a.employee_company_id) as Company," +   
				 " b.address,b.contact_person_name,b.city,b.state,b.pincode,b.email,b.phone "+
				 "FROM "+
				 ""+this.tables.EmployeeMaster+" a ,"+this.tables.AddressMaster+" b WHERE a.address_id = b.id ";
		
			Q +=  ConditionFields ? (" AND " + ConditionFields) : "  ";
		
			Q += " ORDER BY a.id DESC";
			 
			
			db.query(Q,conditionVals,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
			
	}
	
}

module.exports = Employee;