var db = require('../../config/db.js');
var qeObj = require('../query.js');
var tables = require('../tables.js');

var Services = {
	
	tables:tables,
	
	save : function(callback,Fields){
		 
		Q = "INSERT INTO "+this.tables.ServiceMaster+" SET ?"
	
		db.query(Q,Fields,function(err,result){
						
				qe = new qeObj("INSERT",err,result); 
				callback(qe.Exec());
				
		});
	 
				
	},
	
	update : function(callback,Fields,id){
		
		Q = "UPDATE "+this.tables.ServiceMaster+" SET ? WHERE id = ?";
			
			db.query(Q,[Fields,id],function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
		});
			
	},

	saveServiceUnits : function(callback,Fields){
		 
		Q = "INSERT INTO "+this.tables.ServiceUnitsMaster+" SET ?"
	
		db.query(Q,Fields,function(err,result){
						
				qe = new qeObj("INSERT",err,result); 
				callback(qe.Exec());
				
		});
	 
				
	},

	saveServicePrice :function(callback,Fields){
		 
			Q = "INSERT INTO "+this.tables.ServicePrices+" SET ?"
		
			db.query(Q,Fields,function(err,result){
							
					qe = new qeObj("INSERT",err,result); 
					callback(qe.Exec());
					
			});
	 
				
	},

	selectServiceUits : function(callback){

		Q = "SELECT * FROM "+this.tables.ServiceUnitsMaster;

		db.query(Q,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
		});

	},
	
	updateServiceUnits : function(callback,Fields,id){
		
		Q = "UPDATE "+this.tables.ServiceUnitsMaster+" SET ? WHERE id = ?";
			
			db.query(Q,[Fields,id],function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
		});
			
	},

	updateServicePrice : function(callback,Fields,id){
		
		Q = "UPDATE "+this.tables.ServicePrices+" SET ? WHERE id = ?";
			
			db.query(Q,[Fields,id],function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
		});
			
	},
	
	setStatus:function(callback,status,Id){
		
			Q = "UPDATE "+this.tables.ServiceMaster+" SET status = "+status+" WHERE id = '"+Id+"' ";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});
			
	},

	setServicePriceStatus :function(callback,status,Id){
		
			Q = "UPDATE "+this.tables.ServicePrices+" SET status = "+status+" WHERE id = '"+Id+"' ";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});


	},
	
	select : function(callback,ConditionFields,conditionVals){
		 
			Q  = "SELECT"+
				 " a.id,a.service_name,a.parent_id,a.status,(SELECT st.status FROM "+this.tables.Status+" st WHERE st.id = a.status) as status_text FROM "+
				 ""+this.tables.ServiceMaster+" a  WHERE 1=1 ";
			
			Q +=  ConditionFields ? (" AND " + ConditionFields) : "  ";
		
			Q += " ORDER BY a.id DESC";
			
			db.query(Q,conditionVals,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
			
	},

	selectServicePrices : function(callback,condition){

			Q = "SELECT id,service_id,unit_id,customer_price,third_party_price,qty FROM "+this.tables.ServicePrices+" WHERE "+condition;

			db.query(Q,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});

	},

	selectFinalChild : function(callback){
			
			Q  = "SELECT"+
				 " id,service_name,parent_id  FROM "+
				 this.tables.ServiceMaster+
				 " a  WHERE  id not in ( select parent_id from "+this.tables.ServiceMaster+" WHERE status > -1 )  AND status > -1 AND parent_id <> 0";
			 	
			db.query(Q,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});

	},

	selectParentService : function(callback,id){

			Q  = "SELECT"+
				 " id,service_name,parent_id  FROM "+
				 this.tables.ServiceMaster+
				 " a  WHERE  id = ? ";	
			  

			db.query(Q,[id],function(err,result){ 
				  
					qe = new qeObj("SELECT",err,result);

					callback(qe.Exec());
 				  	 
			});		

	},
 
	addCompanyService : function(callback,Fields){
		
		    Q = "INSERT INTO "+this.tables.CompanyServiceMaster+" SET ? ";
			
			db.query(Q,[Fields],function(err,result){
				
					
					qe = new qeObj("INSERT",err,result); 
					callback(qe.Exec());

			});
		
	},
	removeCompanyService : function(callback,Fields){
		
		    Q = "DELETE FROM "+this.tables.CompanyServiceMaster+" WHERE company_id = ? AND service_id = ? ";
			
			db.query(Q,Fields,function(err,result){
						
				qe = new qeObj("DELETE",err,result); 
				callback(qe.Exec());
				
			});
		
	},
	
	CompanyServiceList : function(callback,ConditionFields,conditionVals){
		 
			Q  = "SELECT"+
				 " a.id,a.service_name,a.parent_id FROM "+
				 ""+this.tables.ServiceMaster+" a , "+this.tables.CompanyServiceMaster+" b WHERE a.id = b.service_id ";
		
			Q +=  ConditionFields ? (" AND " + ConditionFields) : "  ";
		
			Q += " ORDER BY a.id DESC";
			 
			db.query(Q,conditionVals,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
			
	},

	
}

module.exports = Services;