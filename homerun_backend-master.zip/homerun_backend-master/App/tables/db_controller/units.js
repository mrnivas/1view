var db = require('../../config/db.js');
var qeObj = require('../query.js');
var tables = require('../tables.js');

var Units = {
	
	tables:tables,
	
	save : function(callback,Fields){
		 
			Q = "INSERT INTO "+this.tables.UnitsMaster+" SET ?"
		
			db.query(Q,Fields,function(err,result){
							
					qe = new qeObj("INSERT",err,result); 
					callback(qe.Exec());
					
			});
	 
				
	},

	
	update : function(callback,Fields,id){
		
			Q = "UPDATE "+this.tables.UnitsMaster+" SET ? WHERE id = ?";
				
				db.query(Q,[Fields,id],function(err,result){
								
						qe = new qeObj("UPDATE",err,result); 
						callback(qe.Exec());
						
			});
			
	},
	
	setStatus:function(callback,status,Id){
		
			Q = "UPDATE "+this.tables.UnitsMaster+" SET status = "+status+" WHERE id = '"+Id+"' ";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});
			
	},
	
	select : function(callback,ConditionFields,conditionVals){
		 
			Q  = "SELECT"+
				 " a.id,a.unit_name,a.incrementable,a.status FROM "+
				 ""+this.tables.UnitsMaster+" a  WHERE 1=1 ";
			
			Q +=  ConditionFields ? (" AND " + ConditionFields) : "  ";
		
			Q += " ORDER BY a.id DESC";
 
			
			db.query(Q,conditionVals,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
			
	} 

	
}

module.exports = Units;