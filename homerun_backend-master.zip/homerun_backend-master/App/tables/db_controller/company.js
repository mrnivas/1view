var db = require('../../config/db.js');
var qeObj = require('../query.js');
var tables = require('../tables.js');

var Companies = {
	
	tables:tables,
	
	save : function(callback,Fields){
		 
		Q = "INSERT INTO "+this.tables.CompanyHubMaster+" SET ?"
	
		db.query(Q,Fields,function(err,result){
						
				qe = new qeObj("INSERT",err,result); 
				callback(qe.Exec());
				
		});
	 
				
	},
	
	update : function(callback,Fields,id){
		
		Q = "UPDATE "+this.tables.CompanyHubMaster+" SET ? WHERE id = ?";
			
			db.query(Q,[Fields,id],function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
		});
			
	},
	
	updateCompanyCode : function(callback,CompanyId,CompanyPrefix){
		
		Q = "UPDATE "+this.tables.CompanyHubMaster+" SET company_code = CONCAT('"+CompanyPrefix+"',LPAD('"+CompanyId+"',10,0)) WHERE id = '"+CompanyId+"' ";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("UPDATE",err,result);

					Q = "SELECT CONCAT('"+CompanyPrefix+"',LPAD('"+CompanyId+"',10,0)) as code";

					if(qe.Exec().status == "done"){

						db.query(Q,function(err,result){

							qe = new qeObj("SELECT",err,result);
							callback(qe.Exec());

						})

					}
					else{
						
						callback(qe.Exec());
					
					}
			});
			
	},
	
	setStatus:function(callback,status,CompanyId){
		
			Q = "UPDATE "+this.tables.CompanyHubMaster+" SET status = "+status+" WHERE id = '"+CompanyId+"' ";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});
			
	},
	
	select : function(callback,ConditionFields,conditionVals){
		 
			Q  = "SELECT"+
				 " a.id,a.company_hub_name,a.status,a.company_code,a.company_logo,a.is_primary,a.parent_id,a.address_id,a.company_type as type, "+
				 " b.address,b.phone,b.contact_person_name,b.city,b.state,b.pincode,b.email,b.contact_person_phone "+
				 "FROM "+
				 ""+this.tables.CompanyHubMaster+" a ,"+this.tables.AddressMaster+" b WHERE a.address_id = b.id ";
		
			Q +=  ConditionFields ? (" AND " + ConditionFields) : "  ";
		
			Q += " ORDER BY a.id DESC";
  			
			 

			db.query(Q,conditionVals,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
			
	},

	isValidHub : function(callback,Company_id,hub_id){

			Q = "SELECT COUNT(*) as total from "+this.tables.CompanyHubMaster+" WHERE parent_id = ? AND id = ? AND company_type= ?";

			db.query(Q,[Company_id,hub_id,'HUB'],function(err,result){

				qe = new qeObj("SELECT",err,result); 
				
				result = qe.Exec();

				var BooleanResult;

				if(result.status == "error"){

					BooleanResult = false;	

				}

				if(result.status == "done"){

					BooleanResult = true;

					if(result.data[0].total == "0"){

						BooleanResult = false;

					}

				}

				callback(BooleanResult);

			});

	}
	
}

module.exports = Companies;