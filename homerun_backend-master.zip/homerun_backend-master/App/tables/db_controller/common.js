var db = require('../../config/db.js');
var qeObj = require('../query.js');
var tables = require('../tables.js');

var Common = {
	
	tables:tables, 
	
	StateList : function(callback){
		 
			Q  = "SELECT"+
				 " StateId,StateName FROM "+
				 ""+this.tables.StateMaster;
		
			Q += " ORDER BY StateName ASC";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
			
	},

	
}

module.exports = Common;