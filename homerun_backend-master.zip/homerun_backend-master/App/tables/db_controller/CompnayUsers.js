var db = require('../../config/db.js');
var qeObj = require('../query.js');
var tables = require('../tables.js');

var Users = {
	
	tables:tables,
	
	save:function(callback,Fields){
		
		Q = "INSERT INTO "+this.tables.UserMaster+" SET ?"
		
		db.query(Q,Fields,function(err,result){
						
				qe = new qeObj("INSERT",err,result); 
				callback(qe.Exec());
				
		});
		
	},
	update:function(callback,Fields,UserId){
		
		if(Fields.old_password){
			
			delete Fields.old_password;
			
		}
		
		Q = "UPDATE "+this.tables.UserMaster+" SET ? WHERE id = ?";
			
			db.query(Q,[Fields,UserId],function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});
			
	},
	setStatus:function(status,callback,UserId){
		
			Q = "UPDATE "+this.tables.UserMaster+" SET status = '"+status+"' WHERE id = '"+UserId+"' ";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});
			
	},
	selectCompanyId:function(callback,userId){
		
			Q = "SELECT company_hub_id as id from "+this.tables.CompanyUserMaster+" where user_id = ?";
			
			db.query(Q,[userId],function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
		
	},
	select:function (){
		
			arg = Users.select.arguments ;
			callback = arg[0];
			ConditionFields = arg[1] ? arg[1] : [] ;
			keys = arg[2] ? arg[2] : "";
		
			Q  = "SELECT"+
				 " username,id,user_role,email,status,created_at FROM "+
				 this.tables.UserMaster+" WHERE 1=1 "+ 
				 ( ConditionFields.length > 0 ? (  keys!=''? ( " AND "+keys ) : " AND ? " ) : "" )  ;
			
			Q += " ORDER BY id DESC";
			
			var  QueryResult;
			 
			db.query(Q,ConditionFields,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
			
	},
	selectDeletedUsersList:function(callback){
		
		Users.select(callback,[{status:'-1'}]);
		
	},
	selectActiveUsers:function(callback){
		
		Users.select(callback,[{status:'1'}]);
		
	},
	selectBLockedUsers:function(callback){
		
		Users.select(callback,[{status:'0'}]);
		
	},
	selectWithoutDeleted:function(callback){
		
		Users.select(callback,[-1]," status <> ? ");
		
	},
	selectRaw:function(callback){
		
		Users.select(callback);
		
	},
	selectOne:function(callback,id){
		
		Users.select(callback,[{id:id}]);
		
	},
	selectExisting:function (callback,fields){
		 
			Q = "SELECT COUNT(id) as rows FROM "+this.tables.UserMaster+" WHERE ? ";
			
			db.query(Q,[fields],function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					
					fldname = Object.keys(fields);
					
					callback(qe.Exec(),fldname[0]);
					
			});
			
		
	},
	Vector:function(fld,callback,UserId){
		
			fields = {id:UserId};
			
			Q = "SELECT "+fld+" as val FROM "+this.tables.UserMaster+" WHERE ? ";
			
			db.query(Q,[fields],function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					
					callback(qe.Exec());
					
			});
		
	}
	
}

module.exports = Users;