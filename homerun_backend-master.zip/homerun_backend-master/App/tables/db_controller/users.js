var db = require('../../config/db.js');
var qeObj = require('../query.js');
var tables = require('../tables.js');
var decodedToken = require('../../libs/decodedToken.js');

var Users = {
	
	tables:tables,
	
	save:function(callback,Fields){
		
		Q = "INSERT INTO "+this.tables.UserMaster+" SET ?";
		
		db.query(Q,Fields,function(err,result){
						
			qe = new qeObj("INSERT",err,result); 
			callback(qe.Exec());
				
		});
		
	},
	deleteCompanyUser:function(callback,Fields){
		
		Q = "DELETE FROM "+this.tables.CompanyUserMaster+" WHERE user_id  = ?";
		
		db.query(Q,Fields,function(err,result){
						
			qe = new qeObj("INSERT",err,result); 
			callback(qe.Exec());
				
		});
		
	},
	saveCompanyUser:function(callback,Fields,id){
		
		var afterDeleted = function(result){
			
			if(result.status == "done"){
										
				Q = "INSERT INTO "+Users.tables.CompanyUserMaster+" SET ?";
		
				db.query(Q,Fields,function(err,result){
								
					qe = new qeObj("INSERT",err,result); 
					callback(qe.Exec());
						
				});
				
			}
			else{
				
				callback(result);
				
			}
			
			
		}
		
		Users.deleteCompanyUser(afterDeleted,[id]);
		
	},
	userRoles:function(callback){
		
		Q = "SELECT * from "+this.tables.UserRollMaster+" WHERE 1=1 ";
		  
		if(decodedToken.token.user_role!=1){
		
			if( decodedToken.token.user_role == 4){
					
				Q += " AND id in (4,2) ";		
					
			}
			else if( decodedToken.token.user_role == 3 ){
				
				Q += " AND id in (4,3,2) ";		
				
			}
			else {
				
				Q += " AND id = 0 ";		
				
			}
		
		}

		db.query(Q,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
		});
		
	},
	update:function(callback,Fields,UserId){
		
		if(Fields.old_password){
			
			delete Fields.old_password;
			
		}
		
		Q = "UPDATE "+this.tables.UserMaster+" SET ? WHERE id = ?";
			
			db.query(Q,[Fields,UserId],function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});
			
	},
	setStatus:function(status,callback,UserId){
		
			Q = "UPDATE "+this.tables.UserMaster+" SET status = '"+status+"' WHERE id = '"+UserId+"' ";
			 
			db.query(Q,function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});
			
	},
	selectCompanyId:function(callback,userId){
		
			Q = "SELECT company_id,hub_id  from "+this.tables.CompanyUserMaster+" where user_id = ?";
			
			db.query(Q,[userId],function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
		
	},
	select:function (){
		
			arg = Users.select.arguments ;
			callback = arg[0];
			ConditionFields = arg[1] ? arg[1] : [] ;
			keys = arg[2] ? arg[2] : "";
			
			//if(decodedToken.token.user_role == "1"){
					
				Q  = "SELECT"+
					 " username,a.id,c.role_name as user_role_name,user_role,email,(SELECT st.status FROM "+this.tables.Status+" st WHERE st.id = a.status) as status_text,a.status,DATE_FORMAT(created_at,'%a, %d %b %Y  %r') as created_at,b.company_id,b.hub_id FROM "+
				     this.tables.UserMaster+" a LEFT OUTER JOIN "+this.tables.CompanyUserMaster+" b ON  b.user_id = a.id, "+this.tables.UserRollMaster+" c WHERE 1=1 AND a.user_role = c.id "+ 
				     ( ConditionFields.length > 0 ? (  keys!=''? ( " AND "+keys ) : " AND ? " ) : "" )  ;
				Q += " ORDER BY a.id DESC";

 
			//}
			/*else{
				
				Q  = "SELECT"+
					 " a.username,a.id,a.user_role,a.email,a.status,a.created_at,b.company_hub_id FROM "+
					 this.tables.UserMaster+" a , "+
					 this.tables.CompanyUserMaster+" b WHERE b.company_hub_id = '"+(decodedToken.token.company_id)+"' and b.user_id = a.id "+ 
					 ( ConditionFields.length > 0 ? (  keys!=''? ( " AND "+keys ) : " AND ? " ) : "" )  ;
				Q += " ORDER BY a.id DESC";
				
			} */
 
			 
			db.query(Q,ConditionFields,function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					callback(qe.Exec());
					
			});
			
	},
	selectDeletedUsersList:function(callback){
		
		Users.select(callback,[{status:'-1'}]);
		
	},
	selectActiveUsers:function(callback){
		
		Users.select(callback,[{status:'1'}]);
		
	},
	selectBLockedUsers:function(callback){
		
		Users.select(callback,[{status:'0'}]);
		
	},
	selectWithoutDeleted:function(callback){
		
		Users.select(callback,[-1]," a.status <> ? ");
		
	},
	userGrid:function(callback,company_id,role){

		var roleCond ;

		if(role!="0"){

				roleCond = " AND c.id = ? " 

		}
		else{

				roleCond = " AND c.id <> ? "
		
		}

		if(decodedToken.token.user_role != 1){

			if(decodedToken.token.company_id){
				
				company_id = decodedToken.token.company_id;

			}
			else{

				callback({"status":"error","msg":"Invalid request"});
				return;
			}

			if( decodedToken.token.user_role == 4 ){

				roleCond += " AND c.id not in ( 1,3 ) ";

			}	
			if(decodedToken.token.user_role == 2){

				roleCond += " AND c.id not in ( 1,3,4 ) ";

			}		
		
		}

		console.log(roleCond);

		Users.select(callback,[company_id,-1,role]," b.company_id = ? AND a.status <> ?"+roleCond);		

	},
	selectRaw:function(callback){
		
		Users.select(callback);
		
	},
	selectOne:function(callback,id){
		
		Users.select(callback,[{"a.id":id}]);
		
	},
	selectExisting:function (callback,fields){
		 
			Q = "SELECT COUNT(id) as rows FROM "+this.tables.UserMaster+" WHERE ? ";
			
			db.query(Q,[fields],function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					
					fldname = Object.keys(fields);
					
					callback(qe.Exec(),fldname[0]);
					
			});
			
		
	},
	Vector:function(fld,callback,UserId){
		
			fields = {id:UserId};
			
			Q = "SELECT "+fld+" as val FROM "+this.tables.UserMaster+" WHERE ? ";
			
			db.query(Q,[fields],function(err,result){
							
					qe = new qeObj("SELECT",err,result); 
					
					callback(qe.Exec());
					
			});
		
	}
	
}

module.exports = Users;