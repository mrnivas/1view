var db = require('../../config/db.js');
var qeObj = require('../query.js');
var tables = require('../tables.js');


var Address = {
	
	tables:tables,
	
	save : function(callback,Fields){
		 	
			Q = "INSERT INTO "+this.tables.AddressMaster+" SET ?"
			
			db.query(Q,Fields,function(err,result){
							
					qe = new qeObj("INSERT",err,result); 
					callback(qe.Exec());
					
			});
	 
	},
	
	update:function(callback,Fields,id){
		
			Q = "UPDATE "+this.tables.AddressMaster+" SET ? WHERE id = ?";
			
			db.query(Q,[Fields,id],function(err,result){
							
					qe = new qeObj("UPDATE",err,result); 
					callback(qe.Exec());
					
			});
		
	}, 
	delete:function(){
		
		
	},
	
	select:function(){
		
		
	}
	
}

module.exports = Address;