var QueryExecuter = function (option,err,result){
	
	this.Qoption = option;
	this.Qerr = err;
	this.Qresult = result;
	
}
  
QueryExecuter.prototype.Exec = function(){  

			var Result;

			if(this.Qerr){ 
			
				Result = {"status":"error","msg":"db connection issue"}; 
				
			 	console.log(this.Qerr);
						
			} 
			else { 

				switch(this.Qoption){
					
					case "SELECT":
						
						Result = {"status":"done","data":this.Qresult};
						
					break;
					
					case "INSERT":
						
						Result = {"status":"done","id":this.Qresult.insertId};
						
					break;
					
					default:
						
						Result ={"status":"done"};
					
					break;
				}
				
			} 
			  
			return Result;
				 
	}
 

module.exports = QueryExecuter;