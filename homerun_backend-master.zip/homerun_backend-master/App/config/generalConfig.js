var configs = function(){ 
		return {
							"dbUser":"root",
							"dbPassword":"root",
							"dbHost":"localhost",
							"dbName":"UDSHUB",
							"authUrlPrefix":'/api/auth',
							"CompanyCodePrefix":"UDSCNY",
							"HUBCodePrefix":"UDSHUB",
							"TablePrefix":"uds_hub_",
							"EmployeeCodePrefix":"UDSEMP",
		};
}
module.exports = configs();
