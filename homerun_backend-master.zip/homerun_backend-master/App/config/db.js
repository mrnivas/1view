var mysql      = require('mysql');
var config = require('./generalConfig.js');

var connection = mysql.createConnection({
		host     : config.dbHost,
		user     : config.dbUser,
		password : config.dbPassword,
		database : config.dbName
});

connection.connect(function(err) {

    if (err) {
	    console.error('error connecting: ' + err.stack);
	    //return;
	}

});

module.exports = connection;