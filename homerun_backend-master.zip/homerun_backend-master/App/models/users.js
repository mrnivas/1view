var users = require('../tables/db_controller/users.js');
var decodedToken = require('../libs/decodedToken.js');

var UserModel = {
	
	userId : 0,
	
	CompanyId : decodedToken.company_id,
	
	callback : function(){},
	
	getUserName:function(){
			
			users.Vector("username",this.callback,this.userId);
			
	},
	
	getPassword:function(){
			
			users.Vector("password",this.callback,this.userId);
			
	},
	
	getPasswordSalt:function(){
			
			users.Vector("salt",this.callback,this.userId);
			
	},
	
	getEmail:function(){
			
			users.Vector("email",this.callback,this.userId);
			
	},
	 
	getStatus:function(){
			
			users.Vector("user_role",this.callback,this.userId);
			
	},
	
	getUserRole:function(){
			
			users.Vector("user_role",this.callback,this.userId);
			
	}
	
}

module.exports = UserModel;