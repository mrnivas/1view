var UnitsController = require('../tables/db_controller/units.js');

var UnitsModel = {
	
		
		get : function(){
				 

				args = UnitsModel.get.arguments;
				
				callback = args[0];
				
				if( typeof(args[1]) == "object"  ){
					
					condFields = Object.keys(args[1])[0];
					condVals =  args[1][Object.keys(args[1])[0]] ;
					
					
				}
				else{
					
					condFields = " AND a.id = ?";
					condVals = [args[1]];
					
				}
					 
				
				UnitsController.select(callback,condFields,condVals);
	
		} 
	 

}


module.exports = UnitsModel;
