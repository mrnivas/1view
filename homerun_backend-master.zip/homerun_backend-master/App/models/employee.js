var EmployeeController = require('../tables/db_controller/employee.js');

var EmployeeModel = {
	
		
		get : function(){
				
				args = EmployeeModel.get.arguments;
				
				callback = args[0];
				
				if( typeof(args[1]) == "object"  ){
					
					condFields = Object.keys(args[1])[0];
					condVals =  args[1][Object.keys(args[1])[0]] ;
					
					
				}
				else{
					
					condFields = " a.id = ?";
					condVals = [args[1]];
					
				}
				
				
				EmployeeController.select(callback,condFields,condVals);
	
		}


}


module.exports = EmployeeModel;
