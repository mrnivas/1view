var CompanyController = require('../tables/db_controller/company.js');

var companyModel = {
	
		
		get : function(){
				
				args = companyModel.get.arguments;
				
				callback = args[0];
				
				if( typeof(args[1]) == "object"  ){
					
					condFields = Object.keys(args[1])[0];
					condVals =  args[1][Object.keys(args[1])[0]] ;
					
					
				}
				else{
					
					condFields = " AND a.id = ?";
					condVals = [args[1]];
					
				}
					 
				
				CompanyController.select(callback,condFields,condVals);
	
		}


}


module.exports = companyModel;
