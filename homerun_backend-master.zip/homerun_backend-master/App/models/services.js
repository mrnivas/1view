var ServicesController = require('../tables/db_controller/services.js');

var ServicesModel = {
	
		
		get : function(){
				
				args = ServicesModel.get.arguments;
				
				callback = args[0];
				
				if( typeof(args[1]) == "object"  ){
					
					condFields = Object.keys(args[1])[0];
					condVals =  args[1][Object.keys(args[1])[0]] ;
					
					
				}
				else{
					
					condFields = " AND a.id = ?";
					condVals = [args[1]];
					
				}
					 
				
				ServicesController.select(callback,condFields,condVals);
	
		},

		getServiceUnitList : function(callback){
			
			ServicesController.selectServiceUits(callback);

		},

		getSingleLineServiceList : function(callback){

			var Services = [];
 

			var FullLength = 0;

			var AddSevricces = function(CurrentLength,result){		

				if(result.status == "done"){		

					if(result.data.length > 0){

						curLength = Services[CurrentLength]['serviceNames'].length;
 
						Services[CurrentLength]['serviceNames'][curLength] = result.data[0].service_name;

						Services[CurrentLength]['serviceNamesIds'][curLength] = result.data[0].id;						
 						   
						if(result.data[0].parent_id != "0"){

							ServicesController.selectParentService(function(res){

								AddSevricces(CurrentLength,res);

							},result.data[0].parent_id);
					 			
						}

						else if( Services[CurrentLength].id  ==  FinalChild){

 								for( var i in Services ){

 									 Services[i]['serviceNames'].reverse();

 									 Services[i]['serviceNamesIds'].reverse();

									 Services[i]['serviceNamesList'] = Services[i]['serviceNames'];  									 

 									 JoinedString = Services[i]['serviceNames'].join(" > ");	

 									 Services[i]['serviceNames'] = JoinedString;

 								}

								callback({status:"done",data:Services}); return;	
							 
						}

					}
					else{

						callback({status:"done",data:Services}); return;

					}

				}
				else{



					callback(result); return;

				}

			}

			var FinalChild  = 0;

			var InitLevelcallback = function(result){

				if(result.status == "done"){

					FullLength = result.data.length;

					if(result.data.length > 0){

						FinalChild = result.data[result.data.length-1].id;

						for(var i in result.data){

							CurrentLength = Services.length;

							Services[CurrentLength] = {'id': result.data[i].id};

							Services[CurrentLength]['serviceNames'] = [];

							Services[CurrentLength]['serviceNamesIds'] = [];

							AddSevricces(CurrentLength,{status:"done",data:[result.data[i]]});

						}	
 
					}
					else{

						callback(result);

					}

				}
				else{

					callback(result);

				}

			}

			ServicesController.selectFinalChild(InitLevelcallback);


		},

		getServicePrices:function(callback){

			ServicesController.selectServicePrices(callback,"status <> -1");

		}  
	 

}


module.exports = ServicesModel;
